import { useState, useEffect } from 'react';
import { 
  Search, Sparkles, MapPin, ShieldCheck, Calculator, Gauge, Zap, 
  Sliders, Calendar, ChevronRight, Star, X, MessageSquare, Plus, 
  Clock, Heart, Share2, Phone, AlertTriangle, QrCode, User, Store, 
  BarChart3, CheckCircle2, DollarSign, ArrowLeftRight
} from 'lucide-react';
import { 
  MOCK_CARS, MOCK_SHOWROOMS, MOCK_GARAGES, INITIAL_LEADS, INITIAL_BOOKINGS, 
  CURRENCY_SYMBOLS, CURRENCY_CONVERSION, formatPrice 
} from './mockData';
import { Car, Showroom, Garage, Booking, Lead, ChatMessage, UserRole } from './types';

export default function App() {
  // Region & Wallet Settings
  const [selectedCurrency, setSelectedCurrency] = useState<'USD' | 'EUR' | 'INR' | 'AED' | 'GBP'>('USD');
  const [activeRole, setActiveRole] = useState<UserRole>('buyer');
  
  // Real-time state pools
  const [cars, setCars] = useState<Car[]>(MOCK_CARS);
  const [showrooms, setShowrooms] = useState<Showroom[]>(MOCK_SHOWROOMS);
  const [garages, setGarages] = useState<Garage[]>(MOCK_GARAGES);
  const [leads, setLeads] = useState<Lead[]>(INITIAL_LEADS);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [savedCarIds, setSavedCarIds] = useState<string[]>(['car-2', 'car-5']);

  // Filters & Search
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'New' | 'Used' | 'Luxury' | 'EV' | 'Auction'>('All');
  const [searchBrand, setSearchBrand] = useState('');
  const [searchBudget, setSearchBudget] = useState('all');
  const [searchFuel, setSearchFuel] = useState('all');
  const [searchCountry, setSearchCountry] = useState('all');
  const [searchLuxury, setSearchLuxury] = useState('all');

  // Detailed Modal Views
  const [activeCarDetails, setActiveCarDetails] = useState<Car | null>(null);
  const [activeShowroomDetails, setActiveShowroomDetails] = useState<Showroom | null>(null);
  const [activeGarageDetails, setActiveGarageDetails] = useState<Garage | null>(null);

  // Compare Engine
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  // Simulated 360 Viewer State
  const [viewerAngle, setViewerAngle] = useState(0);

  // Interactive Loan Calculator Defaults
  const [loanTerm, setLoanTerm] = useState(60); // months
  const [loanInterest, setLoanInterest] = useState(4.9); // % 
  const [downPaymentPercent, setDownPaymentPercent] = useState(20); // %

  // AI Interactive State Controllers
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', sender: 'ai', text: 'Welcome to **Detex Auto Elite Lounge**. I have scanned our real-time inventory in Las Vegas, Munich, Dubai, and Tokyo. Ask me for future resale models, high-performance EVs, or request real-time spec comparisons!', timestamp: 'Just now' }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  // Recommendations state
  const [recInputs, setRecInputs] = useState({ budget: 300000, pref: 'High Performance Track Star', ev: 'Hybrid' });
  const [recommendedCars, setRecommendedCars] = useState<any[]>([]);
  const [loadingRecs, setLoadingRecs] = useState(false);

  // Future Prediction state
  const [resaleLoading, setResaleLoading] = useState(false);
  const [resalePredictions, setResalePredictions] = useState<any[]>([]);
  const [resaleSynopsis, setResaleSynopsis] = useState('');

  // Physical Showroom QR simulation & check-ins
  const [qrCodeModal, setQrCodeModal] = useState(false);
  const [scannedShowroomPromo, setScannedShowroomPromo] = useState<string | null>(null);

  // Checkout simulation
  const [checkoutBooking, setCheckoutBooking] = useState<{ car: Car; type: 'test' | 'reserve' } | null>(null);
  const [checkoutDate, setCheckoutDate] = useState('2026-05-25');
  const [checkoutTime, setCheckoutTime] = useState('11:00');
  const [transactionSuccess, setTransactionSuccess] = useState(false);

  // SOS Roadside support system
  const [sosStatus, setSosStatus] = useState<'idle' | 'calling' | 'dispatched'>('idle');
  const [sosCoords, setSosCoords] = useState('');
  const [beepingAlert, setBeepingAlert] = useState(false);

  // Showroom addition form
  const [newCarForm, setNewCarForm] = useState({
    brand: '', model: '', year: 2026, category: 'Luxury' as any, priceExShowroom: 150000,
    topSpeed: 300, horsepower: 700, acceleration: '3.1s'
  });

  // Countdown timer for Live Showroom Auction Demo
  const [auctionTimeLeft, setAuctionTimeLeft] = useState('02:45:18');
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const hrs = 23 - now.getUTCHours();
      const mins = 59 - now.getUTCMinutes();
      const secs = 59 - now.getUTCSeconds();
      setAuctionTimeLeft(
        `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Filter cars logic
  const filteredCars = cars.filter(car => {
    // Category tabs
    if (selectedCategory !== 'All') {
      if (selectedCategory === 'Auction' && car.category !== 'Auction' && car.id !== 'car-7') return false;
      if (selectedCategory === 'EV' && car.category !== 'EV') return false;
      if (selectedCategory === 'Luxury' && car.category !== 'Luxury') return false;
      if (selectedCategory === 'Used' && car.condition !== 'Used') return false;
      if (selectedCategory === 'New' && car.condition !== 'New' && car.condition !== 'Certified') return false;
    }
    // Search selectors
    if (searchBrand && !car.brand.toLowerCase().includes(searchBrand.toLowerCase())) return false;
    if (searchFuel !== 'all') {
      const isEv = car.mileage.toLowerCase().includes('electric') || car.mileage.toLowerCase().includes('range');
      if (searchFuel === 'Electric' && !isEv) return false;
      if (searchFuel === 'Hybrid' && !car.mileage.toLowerCase().includes('hybrid')) return false;
      if (searchFuel === 'Petrol' && (isEv || car.mileage.toLowerCase().includes('hybrid'))) return false;
    }
    if (searchCountry !== 'all' && car.country.toLowerCase() !== searchCountry.toLowerCase()) return false;
    
    // Budget bounds
    if (searchBudget !== 'all') {
      const val = car.priceExShowroom;
      if (searchBudget === 'under100k' && val >= 100000) return false;
      if (searchBudget === '100k-500k' && (val < 100000 || val > 500000)) return false;
      if (searchBudget === 'over500k' && val <= 500000) return false;
    }

    if (searchLuxury !== 'all') {
      if (searchLuxury === 'extreme' && car.priceExShowroom < 500000) return false;
      if (searchLuxury === 'entry' && car.priceExShowroom >= 200000) return false;
    }

    return true;
  });

  // Calculate taxes custom by country
  const getTaxesDetail = (car: Car) => {
    let rate = 0.08; // default 8%
    if (car.country === 'United Arab Emirates') rate = 0.05;
    if (car.country === 'Germany') rate = 0.19;
    if (car.country === 'Japan') rate = 0.10;
    const taxes = Math.round(car.priceExShowroom * rate);
    const regFee = Math.round(car.priceExShowroom * 0.015);
    const onRoadEst = car.priceExShowroom + taxes + regFee + car.insuranceEstimate;
    return { taxes, regFee, onRoadEst };
  };

  // Chat agent call
  const handleSendChat = async (presetText?: string) => {
    const textToSend = presetText || chatInput;
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), sender: 'user', text: textToSend, timestamp: 'Now' };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setChatLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: chatMessages
        })
      });
      const data = await response.json();
      setChatMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: data.reply,
        timestamp: 'Now'
      }]);
    } catch {
      setChatMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: "**Offline Mode Enabled.** High mechanical and system telemetry for performance cars show optimal resale value when certified directly inside Detex dealerships.",
        timestamp: 'Now'
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  // Launch live resale predictions
  const fetchResalePredictions = async (car: Car) => {
    setResaleLoading(true);
    try {
      const res = await fetch('/api/gemini/predict-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelName: car.model,
          brand: car.brand,
          priceExShowroom: car.priceExShowroom,
          condition: car.condition,
          mileage: car.mileage,
          year: car.year
        })
      });
      const data = await res.json();
      setResalePredictions(data.projectedValues || []);
      setResaleSynopsis(data.marketAnalysis || '');
    } catch (e) {
      // rule based fallback
      const base = car.priceExShowroom;
      const isCol = car.priceExShowroom > 400000;
      const list = [];
      let temp = base;
      for (let i = 1; i <= 5; i++) {
        temp = isCol ? temp * 1.03 : temp * 0.88;
        list.push({ year: i, valueUsd: Math.round(temp), percentage: Math.round((temp / base) * 100) });
      }
      setResalePredictions(list);
      setResaleSynopsis(`The ${car.brand} ${car.model} displays robust residual profiles. Hybrid & luxury mechanics retain significant collector interest, pacing well against typical depreciation paradigms.`);
    } finally {
      setResaleLoading(false);
    }
  };

  // Call recommendation smart handler
  const fetchSmartRecommendations = async () => {
    setLoadingRecs(true);
    try {
      const response = await fetch('/api/gemini/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          budgetUsd: recInputs.budget,
          preference: recInputs.pref,
          evPreference: recInputs.ev,
          region: 'Vegas'
        })
      });
      const data = await response.json();
      setRecommendedCars(data);
    } catch {
      setRecommendedCars([
        { brand: 'Lamborghini', model: 'Revuelto', estimatedPriceUsd: 608000, suitabilityScore: 97, rationale: 'V12 electrical pairing is perfect for maximum extreme supercar response and sound signature.' },
        { brand: 'Tesla', model: 'Model S Plaid', estimatedPriceUsd: 89990, suitabilityScore: 92, rationale: 'The acceleration value is completely unmatched globally with high battery efficiency.' }
      ]);
    } finally {
      setLoadingRecs(false);
    }
  };

  // Save/Unsave car
  const toggleSaveCar = (id: string, e?: any) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    if (savedCarIds.includes(id)) {
      setSavedCarIds(prev => prev.filter(cId => cId !== id));
    } else {
      setSavedCarIds(prev => [...prev, id]);
    }
  };

  // Live auction place simulation bid
  const makeLiveBid = (carId: string) => {
    setCars(prev => prev.map(c => {
      if (c.id === carId || (carId === 'car-7' && c.id === 'car-7')) {
        const curBid = c.auctionDetails?.currentBid || c.priceExShowroom;
        const inc = c.auctionDetails?.minIncrement || 5000;
        return {
          ...c,
          auctionDetails: {
            currentBid: curBid + inc,
            minIncrement: inc,
            endTime: c.auctionDetails?.endTime || 'Tomorrow 18:00',
            bidsCount: (c.auctionDetails?.bidsCount || 0) + 1
          }
        };
      }
      return c;
    }));
  };

  // Book showroom ticket/purchase
  const proceedShowroomReservation = (e: any) => {
    e.preventDefault();
    if (!checkoutBooking) return;
    
    // Create lead & booking states
    const newBooking: Booking = {
      id: 'bk-' + Math.random().toString(36).substring(4, 9),
      carId: checkoutBooking.car.id,
      carName: `${checkoutBooking.car.brand} ${checkoutBooking.car.model}`,
      showroomId: checkoutBooking.car.showroomId,
      showroomName: checkoutBooking.car.showroomName,
      buyerName: 'Vikram Patel',
      buyerEmail: 'anand.yukti.mandar@gmail.com',
      bookingAmountPaid: checkoutBooking.type === 'reserve' ? 5000 : 0,
      date: checkoutDate,
      time: checkoutTime,
      type: checkoutBooking.type === 'reserve' ? 'Purchase Reservation' : 'Test Drive',
      status: 'confirmed'
    };

    setBookings(prev => [newBooking, ...prev]);

    // Create a physical lead log too for the dealership dashboard
    const newLead: Lead = {
      id: 'ld-' + Math.random().toString(36).substring(4, 9),
      carId: checkoutBooking.car.id,
      carName: `${checkoutBooking.car.brand} ${checkoutBooking.car.model}`,
      buyerName: 'Vikram Patel',
      buyerEmail: 'anand.yukti.mandar@gmail.com',
      buyerPhone: '+971 50 123 4567',
      message: `Formally scheduled a swift ${checkoutBooking.type === 'reserve' ? 'priority delivery slot' : 'VIP track feedback sequence'}. Completed online deposit verifying genuine physical lead status.`,
      status: 'pending',
      date: new Date().toISOString()
    };

    setLeads(prev => [newLead, ...prev]);
    setTransactionSuccess(true);
    setTimeout(() => {
      setTransactionSuccess(false);
      setCheckoutBooking(null);
    }, 2800);
  };

  // Showroom submits brand new vehicle
  const handleCreateCar = (e: any) => {
    e.preventDefault();
    const newCar: Car = {
      id: 'car-' + (cars.length + 1),
      brand: newCarForm.brand || 'Apollo',
      model: newCarForm.model || 'Intensa Emozione',
      year: Number(newCarForm.year),
      category: newCarForm.category,
      condition: 'New',
      priceExShowroom: Number(newCarForm.priceExShowroom),
      priceOnRoad: Math.round(Number(newCarForm.priceExShowroom) * 1.08),
      emiBase: Math.round(Number(newCarForm.priceExShowroom) * 0.015),
      whatsapp: '17025550199',
      insuranceEstimate: 3600,
      showroomId: 'sr-1',
      showroomName: 'Aether Hypercars Vegas',
      mileage: '5.2 km/l (V12 Track Spec)',
      topSpeed: Number(newCarForm.topSpeed),
      horsepower: Number(newCarForm.horsepower),
      torque: 760,
      acceleration: newCarForm.acceleration || '2.7s',
      safetyRating: 5,
      gallery: ['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=800&q=80'],
      colors: [{ name: 'Nero Satin', hex: '#1C1C1F' }],
      availability: 'Pre-Order Only',
      city: 'Las Vegas',
      country: 'United States',
      pros: ['Supreme race track force metrics.', 'Authentic exhaust note, natural intake.'],
      cons: ['Intensely noisy cabin space, zero radio configuration.']
    };

    setCars(prev => [newCar, ...prev]);
    // Notify user
    alert(`Success: Certified ${newCar.brand} ${newCar.model} is now actively broadcast across world showrooms!`);
    setNewCarForm({
      brand: '', model: '', year: 2026, category: 'Luxury', priceExShowroom: 150000,
      topSpeed: 300, horsepower: 700, acceleration: '3.1s'
    });
  };

  // Compare selection toggler
  const toggleCompare = (id: string, e: any) => {
    e.stopPropagation();
    if (compareIds.includes(id)) {
      setCompareIds(prev => prev.filter(item => item !== id));
    } else {
      if (compareIds.length >= 2) {
        alert("Maximum 2 vehicles can be side-by-side compared concurrently. Deselect one first.");
        return;
      }
      setCompareIds(prev => [...prev, id]);
    }
  };

  // Scan physical showroom simulator
  const handleSimulateQRScan = (showroomName: string) => {
    setScannedShowroomPromo(showroomName);
    setQrCodeModal(false);
  };

  // Rapid GPS locator for standard roadside SOS
  const triggerSOSRescue = () => {
    if (sosStatus === 'idle') {
      setSosStatus('calling');
      setBeepingAlert(true);
      // Generate Vegas custom coords
      const lat = (36.1699 + (Math.random() - 0.5) * 0.1).toFixed(4);
      const lng = (-115.1398 + (Math.random() - 0.5) * 0.1).toFixed(4);
      setSosCoords(`${lat}° N, ${lng}° W`);
      setTimeout(() => {
        setSosStatus('dispatched');
        setBeepingAlert(false);
      }, 3000);
    } else {
      setSosStatus('idle');
      setSosCoords('');
    }
  };

  return (
    <div id="detex-app" className="min-h-screen bg-[#0a0a0d] text-slate-100 font-sans selection:bg-[#ff5722] selection:text-white">
      
      {/* BACKGROUND GRAPHIC GLOW */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-[#ff5722]/5 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute top-1/3 left-10 w-[400px] h-[400px] bg-sky-500/5 blur-[120px] rounded-full pointer-events-none" />

      {/* TOP SYSTEM HEADLINE */}
      <div id="system-top-banner" className="bg-gradient-to-r from-orange-600 to-amber-700 text-white text-xs px-4 py-2 text-center font-mono font-medium tracking-wider flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
          <span>DETEX AUTO DECENTRALIZED HYPERCAR GRID SYSTEM READY</span>
        </div>
        <div className="hidden sm:flex items-center gap-4">
          <span>UTC: 2026-05-21 02:08:00</span>
          <span>● ENCRYPTED SSL ACTIVE</span>
        </div>
      </div>

      {/* STRIP GLASS OVERLAY NAVIGATION */}
      <header id="detex-navbar" className="sticky top-0 z-40 bg-zinc-950/80 backdrop-blur-md border-b border-white/[0.06] transition-all">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          
          {/* Brand logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-[#ff5722] to-amber-500 flex items-center justify-center font-display font-extrabold text-white text-xl tracking-tight leading-none shadow-lg glow-orange">
              D
            </div>
            <div>
              <span className="block font-display font-extrabold tracking-widest text-[#ff5722] text-xl">DETEX</span>
              <span className="block text-[9px] font-mono tracking-widest text-slate-400 -mt-1 uppercase">AETHER MOTORS</span>
            </div>
          </div>

          {/* Quick Stats bar inside Header */}
          <div className="hidden lg:flex items-center gap-6 text-xs font-mono text-slate-400">
            <div>
              <span className="text-slate-500">Global Inventory:</span> <strong className="text-orange-500">1,480 Active</strong>
            </div>
            <div>
              <span className="text-slate-500">Showrooms Connected:</span> <strong className="text-white">42 Elite</strong>
            </div>
          </div>

          {/* Currency + System Role Swapper */}
          <div className="flex items-center gap-3">
            
            {/* Currency Selector */}
            <div className="flex items-center gap-1.5 bg-zinc-900 border border-white/10 px-2 py-1.5 rounded-lg">
              <span className="text-slate-500 text-xs font-mono uppercase">Currency:</span>
              <select 
                value={selectedCurrency} 
                onChange={(e) => setSelectedCurrency(e.target.value as any)}
                className="bg-transparent border-none text-xs font-bold text-orange-500 font-mono focus:outline-none cursor-pointer"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="INR">INR (₹)</option>
                <option value="AED">AED</option>
                <option value="GBP">GBP (£)</option>
              </select>
            </div>

            {/* Role Manager Badge selector (Buyer / Showroom Operator / Garage Specialist) */}
            <div className="flex items-center gap-1.5 bg-[#ff5722]/10 border border-[#ff5722]/30 px-2.5 py-1.5 rounded-lg">
              <User className="w-3.5 h-3.5 text-[#ff5722]" />
              <select 
                value={activeRole} 
                onChange={(e) => setActiveRole(e.target.value as any)}
                className="bg-transparent border-none text-xs font-bold text-slate-200 focus:outline-none cursor-pointer uppercase font-mono"
              >
                <option value="buyer">Tester: Buyer Portal</option>
                <option value="showroom">Tester: Showroom Owner</option>
                <option value="garage">Tester: Garage Operator</option>
              </select>
            </div>

            {/* Live Chat Button */}
            <button 
              onClick={() => setChatOpen(true)}
              className="relative p-2 bg-zinc-900 hover:bg-zinc-800 rounded-lg text-slate-200 transition-colors cursor-pointer border border-white/10"
              title="Open AI Concierge"
            >
              <MessageSquare className="w-5 h-5 text-orange-400 animate-pulse" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#ff5722] rounded-full" />
            </button>
          </div>
        </div>
      </header>

      {/* HERO BANNER SECTION & SEARCH ENGINE */}
      <section id="detex-hero" className="relative pt-12 pb-24 overflow-hidden bg-gradient-to-b from-[#0a0a0d] via-zinc-950 to-[#0a0a0d] border-b border-white/[0.04]">
        
        {/* Subtle decorative matrix mesh background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:40px_40px]" />

        <div className="relative max-w-7xl mx-auto px-4 z-10">
          
          {/* Scanning promo notify if active */}
          {scannedShowroomPromo && (
            <div id="promo-banner" className="mb-8 p-3.5 bg-orange-600/20 border border-orange-500 rounded-xl flex items-center justify-between text-sm backdrop-blur-md">
              <span className="font-mono text-slate-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-orange-400" />
                <strong>QR Check-in Active:</strong> You unlocked an exclusive VIP test hospitality package at <strong>{scannedShowroomPromo}</strong>!
              </span>
              <button 
                onClick={() => setScannedShowroomPromo(null)}
                className="text-xs underline text-slate-300 hover:text-white"
              >
                Dismiss Offer
              </button>
            </div>
          )}

          {/* Layout Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Cinematic headings */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-orange-500/20 text-xs text-orange-500 font-mono tracking-widest uppercase">
                <Sparkles className="w-3 h-3" /> NEXTGEN REAL-TIME SHOWROOM SYNC
              </div>
              <h1 className="text-4xl sm:text-6xl font-display font-black tracking-tight leading-none text-white">
                The Global <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-300 to-orange-500 uppercase glow-orange">
                  Hypercar Runway
                </span>
              </h1>
              <p className="text-slate-400 text-base sm:text-lg max-w-2xl font-light">
                Directly linking physical luxury showrooms from Las Vegas, Tokyo, Munich, and Dubai into a single real-time inventory terminal. Complete with AI resale value tracking, interactive 360 views, and immediate showroom-to-buyer WhatsApp networks.
              </p>

              {/* Multi-parameter interactive search engine */}
              <div className="p-4 bg-zinc-900/90 rounded-2xl border border-white/10 shadow-2xl glass-panel space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  
                  {/* Brand select */}
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 mb-1 uppercase tracking-wider">Search brand</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Porsche, Tesla" 
                      value={searchBrand}
                      onChange={(e) => setSearchBrand(e.target.value)}
                      className="w-full bg-zinc-950 border border-white/10 rounded-lg py-1.5 px-2.5 text-xs text-slate-100 placeholder-slate-500 focus:border-orange-500 focus:outline-none"
                    />
                  </div>

                  {/* Range select */}
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 mb-1 uppercase tracking-wider">Max price limit</label>
                    <select 
                      value={searchBudget}
                      onChange={(e) => setSearchBudget(e.target.value)}
                      className="w-full bg-zinc-950 border border-white/10 rounded-lg py-1.5 px-2.5 text-xs text-slate-100 focus:border-orange-500 focus:outline-none cursor-pointer"
                    >
                      <option value="all">Any Limit</option>
                      <option value="under100k">Under $100,000</option>
                      <option value="100k-500k">$100,000 - $500,000</option>
                      <option value="over500k">Over $500,000</option>
                    </select>
                  </div>

                  {/* Engine fuel select */}
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 mb-1 uppercase tracking-wider">Powertrain</label>
                    <select 
                      value={searchFuel}
                      onChange={(e) => setSearchFuel(e.target.value)}
                      className="w-full bg-zinc-950 border border-white/10 rounded-lg py-1.5 px-2.5 text-xs text-slate-100 focus:border-orange-500 focus:outline-none cursor-pointer"
                    >
                      <option value="all">All Specs</option>
                      <option value="Electric">Pure Electric (EV)</option>
                      <option value="Hybrid">Hybrid Tech</option>
                      <option value="Petrol">Gasoline/ICE</option>
                    </select>
                  </div>

                  {/* Country hub select */}
                  <div>
                    <label className="block text-[10px] font-mono text-slate-400 mb-1 uppercase tracking-wider">Region Hub</label>
                    <select 
                      value={searchCountry}
                      onChange={(e) => setSearchCountry(e.target.value)}
                      className="w-full bg-zinc-950 border border-white/10 rounded-lg py-1.5 px-2.5 text-xs text-slate-100 focus:border-orange-500 focus:outline-none cursor-pointer"
                    >
                      <option value="all">All Cities</option>
                      <option value="United States">Las Vegas, USA</option>
                      <option value="Japan">Tokyo, Japan</option>
                      <option value="Germany">Munich, Germany</option>
                      <option value="United Arab Emirates">Dubai, UAE</option>
                    </select>
                  </div>

                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-white/[0.06]">
                  {/* Compare toggle counts */}
                  <div className="text-xs font-mono text-slate-400">
                    {compareIds.length > 0 ? (
                      <span className="text-orange-400">
                        Comparing <strong>{compareIds.length}/2</strong> models
                      </span>
                    ) : (
                      "Select compare checkbox to review spec differences"
                    )}
                  </div>

                  <div className="flex gap-2">
                    {/* Clear selection */}
                    {(searchBrand || searchBudget !== 'all' || searchFuel !== 'all' || searchCountry !== 'all') && (
                      <button 
                        onClick={() => {
                          setSearchBrand(''); setSearchBudget('all'); setSearchFuel('all'); setSearchCountry('all');
                        }}
                        className="text-xs bg-zinc-800 hover:bg-zinc-700 text-slate-300 py-1.5 px-3 rounded-lg font-medium cursor-pointer"
                      >
                        Reset
                      </button>
                    )}

                    {compareIds.length >= 1 && (
                      <button 
                        onClick={() => setShowCompareModal(true)}
                        className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-semibold py-1.5 px-3.5 rounded-lg text-xs cursor-pointer shadow-lg shadow-indigo-500/10"
                      >
                        <ArrowLeftRight className="w-3.5 h-3.5" /> Launch Side-by-Side Compare
                      </button>
                    )}
                  </div>
                </div>

              </div>
            </div>

            {/* AI AUTO RUNWAY RECOMMENDATION ENGINE INTEGRATED */}
            <div className="lg:col-span-5">
              <div className="p-5 bg-gradient-to-br from-zinc-900 to-zinc-950 border border-[#ff5722]/30 rounded-2xl shadow-xl space-y-4 glow-orange">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-orange-500 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-4 text-orange-400" /> GEMINI AUTOMOTIVE BRAIN
                  </span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono uppercase bg-emerald-500/20 text-emerald-400">Active model: 3.5 Flash</span>
                </div>

                <div>
                  <h3 className="text-base font-display font-semibold text-white">AI Instant Matchmaker Advisor</h3>
                  <p className="text-[11px] text-slate-400">Specify preferences below to query our neural model directly for high-suitability marketplace recommendations.</p>
                </div>

                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-mono text-slate-400 block mb-0.5">Budget Limit (USD)</label>
                      <input 
                        type="number" 
                        value={recInputs.budget}
                        onChange={(e) => setRecInputs(prev => ({...prev, budget: Number(e.target.value)}))}
                        className="w-full bg-zinc-950 border border-white/10 rounded-lg p-1.5 text-xs text-slate-100 font-mono" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono text-slate-400 block mb-0.5">Drive Preference</label>
                      <select 
                        value={recInputs.ev}
                        onChange={(e) => setRecInputs(prev => ({...prev, ev: e.target.value}))}
                        className="w-full bg-zinc-950 border border-white/10 rounded-lg p-1.5 text-xs text-slate-100"
                      >
                        <option value="Hybrid">Hybrid Propulsion</option>
                        <option value="Electric">Pure EV Power</option>
                        <option value="Gasoline">Mechanical ICE Only</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-slate-400 block mb-0.5">Automotive Persona Focus</label>
                    <input 
                      type="text" 
                      value={recInputs.pref}
                      onChange={(e) => setRecInputs(prev => ({...prev, pref: e.target.value}))}
                      placeholder="e.g. Luxury Cinema features or Nürburgring performance" 
                      className="w-full bg-zinc-950 border border-white/10 rounded-lg p-1.5 text-xs text-slate-100 placeholder-slate-600" 
                    />
                  </div>
                </div>

                <button 
                  onClick={fetchSmartRecommendations}
                  disabled={loadingRecs}
                  className="w-full py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-mono font-bold text-xs rounded-xl transition-all shadow-lg glow-orange uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loadingRecs ? (
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 animate-spin" /> Fetching Tailored Options...
                    </span>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-white" /> Query Gemini Recommendation Brain
                    </>
                  )}
                </button>

                {/* AI recommendation outputs list */}
                {recommendedCars.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-white/10 space-y-2">
                    <span className="text-[10px] font-mono text-orange-400 block uppercase">Perfect matches generated:</span>
                    {recommendedCars.map((recCar, idx) => (
                      <div key={idx} className="bg-zinc-950/80 p-2.5 rounded-xl border border-white/[0.04]">
                        <div className="flex items-center justify-between">
                          <span className="font-display font-bold text-xs text-white">{recCar.brand} {recCar.model}</span>
                          <span className="text-[10px] text-emerald-400 font-mono font-bold">{recCar.suitabilityScore}% Suitability</span>
                        </div>
                        <p className="text-[10px] text-slate-300 font-light mt-0.5">{recCar.rationale}</p>
                        <span className="text-[9px] text-[#ff5722] font-mono block mt-1">Est. price: {formatPrice(recCar.estimatedPriceUsd, selectedCurrency)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* CORE MARKETPLACE GRID PLATFORM */}
      <main id="detex-marketplace" className="max-w-7xl mx-auto px-4 py-12">
        
        {/* TAB CONTROLLERS */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/[0.08] pb-4 mb-8 gap-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
            {(['All', 'New', 'Used', 'Luxury', 'EV', 'Auction'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs font-mono font-bold uppercase cursor-pointer rounded-lg border transition-all whitespace-nowrap ${
                  selectedCategory === cat 
                  ? 'bg-[#ff5722] text-white border-transparent' 
                  : 'bg-zinc-900 text-slate-400 border-white/[0.05] hover:border-white/10 hover:text-white'
                }`}
              >
                {cat === 'Auction' ? '🔥 Bidding Arena (LIV)' : cat === 'EV' ? '🔌 EV Spotlight' : cat}
              </button>
            ))}
          </div>

          {/* Quick Simulation controls badge */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-500">Demo Controls:</span>
            <button 
              onClick={() => {
                alert("Simulating automated dealer inventory synchronization over live Webhooks... Checked 4 global hubs.");
              }}
              className="text-[10px] font-mono bg-zinc-900 border border-white/10 rounded px-2.5 py-1 text-slate-300 hover:text-white cursor-pointer"
            >
              🔄 Forced Showroom Sync
            </button>
            <button
              onClick={() => setQrCodeModal(true)}
              className="text-[10px] font-mono bg-[#ff5722]/10 border border-[#ff5722]/40 rounded px-2.5 py-1 text-orange-400 hover:text-orange-300 flex items-center gap-1 cursor-pointer"
            >
              <QrCode className="w-3 h-3" /> Simulate QR Check-In
            </button>
          </div>
        </div>

        {/* CARS VEHICLES LIST GRID */}
        {filteredCars.length === 0 ? (
          <div className="text-center py-20 bg-zinc-900/40 rounded-3xl border border-white/[0.05]">
            <Sliders className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <h3 className="text-base font-display font-semibold text-white">No Vehicles matched your filter parameters</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">Try resetting the Powertrain options or broaden your global search limit.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCars.map((car) => {
              const isSaved = savedCarIds.includes(car.id);
              const isAuction = car.category === 'Auction' || car.id === 'car-7';
              const isEv = car.category === 'EV';
              return (
                <div 
                  key={car.id} 
                  id={`car-card-${car.id}`}
                  onClick={() => {
                    setActiveCarDetails(car);
                    fetchResalePredictions(car);
                  }}
                  className="group bg-zinc-900/60 hover:bg-zinc-900 rounded-2xl border border-white/[0.06] overflow-hidden transition-all duration-300 hover:scale-[1.01] hover:border-orange-500/30 flex flex-col justify-between cursor-pointer shadow-lg hover:shadow-2xl hover:glow-orange"
                >
                  
                  {/* Top image panel */}
                  <div className="relative aspect-video w-full bg-zinc-950 overflow-hidden">
                    <img 
                      src={car.gallery[0] || 'https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=400&q=80'} 
                      alt={car.model}
                      className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500 opacity-90" 
                    />
                    
                    {/* Dark gradient shadow */}
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent opacity-60" />

                    {/* Verified badge */}
                    <div className="absolute top-3 left-3 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-zinc-950/80 backdrop-blur-md border border-white/10 text-[10px] font-mono text-emerald-400">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      <span>VEGAS APEX SECURE</span>
                    </div>

                    {/* Save heart icon */}
                    <button 
                      onClick={(e) => toggleSaveCar(car.id, e)}
                      className="absolute top-3 right-3 p-1.5 rounded-full bg-zinc-950/80 backdrop-blur-md border border-white/10 hover:bg-[#ff5722] text-white transition-colors"
                    >
                      <Heart className={`w-3.5 h-3.5 ${isSaved ? 'fill-current text-white' : 'text-slate-300'}`} />
                    </button>

                    {/* Condition tags */}
                    <div className="absolute bottom-3 left-3 flex gap-1.5 items-center">
                      <span className="px-2 py-0.5 rounded bg-[#ff5722]/95 text-white text-[9px] font-mono font-bold uppercase">
                        {car.condition}
                      </span>
                      {isEv && (
                        <span className="px-2 py-0.5 rounded bg-sky-600/90 text-white text-[9px] font-mono font-semibold flex items-center gap-0.5">
                          <Zap className="w-2.5 h-2.5 text-sky-200" /> EV
                        </span>
                      )}
                      {isAuction && (
                        <span className="px-2 py-0.5 rounded bg-red-600 font-mono font-black text-white text-[9px] uppercase animate-pulse">
                          AUCTION
                        </span>
                      )}
                    </div>

                    {/* Local hub indicator */}
                    <div className="absolute bottom-3 right-3 text-[10px] font-mono text-slate-300 flex items-center gap-1 bg-zinc-950/70 py-0.5 px-2 rounded-full backdrop-blur-sm">
                      <MapPin className="w-2.5 h-2.5 text-orange-400" />
                      <span>{car.city}</span>
                    </div>
                  </div>

                  {/* Information Body */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Showroom & Title */}
                      <span className="block text-[10px] font-mono text-slate-400 tracking-wider uppercase mb-1">
                        {car.showroomName}
                      </span>
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-display font-semibold text-white tracking-tight">
                          {car.brand} <span className="text-slate-300">{car.model}</span>
                        </h2>
                        <span className="text-xs font-mono text-slate-400">{car.year}</span>
                      </div>

                      {/* Power metrics bar */}
                      <div className="grid grid-cols-3 gap-1.5 bg-zinc-950/50 p-2 rounded-xl border border-white/[0.04] text-[10px] font-mono text-slate-400 mt-2.5">
                        <div className="text-center">
                          <span className="block text-slate-500 text-[8px] uppercase">Power</span>
                          <span className="text-slate-200 font-bold">{car.horsepower} HP</span>
                        </div>
                        <div className="text-center border-x border-white/[0.06]">
                          <span className="block text-slate-500 text-[8px] uppercase">0-100</span>
                          <span className="text-orange-400 font-bold">{car.acceleration}</span>
                        </div>
                        <div className="text-center">
                          <span className="block text-slate-500 text-[8px] uppercase">Max</span>
                          <span className="text-slate-200 font-bold">{car.topSpeed} km/h</span>
                        </div>
                      </div>
                    </div>

                    {/* Price & Primary Call-to-Action */}
                    <div className="mt-4 pt-3.5 border-t border-white/[0.06] flex items-center justify-between">
                      <div>
                        {isAuction ? (
                          <>
                            <span className="block text-[8px] font-mono text-slate-500 uppercase tracking-widest">Current Active Bid</span>
                            <span className="text-lg font-mono font-bold text-orange-400">
                              {formatPrice(car.auctionDetails?.currentBid || car.priceExShowroom, selectedCurrency)}
                            </span>
                          </>
                        ) : (
                          <>
                            <span className="block text-[8px] font-mono text-slate-500 uppercase tracking-widest">Ex-Showroom Price</span>
                            <span className="text-lg font-mono font-bold text-[#ff5722]">
                              {formatPrice(car.priceExShowroom, selectedCurrency)}
                            </span>
                          </>
                        )}
                        <span className="block text-[9px] font-mono text-slate-400">
                          {isAuction ? `Bids count: ${car.auctionDetails?.bidsCount || 4}` : `Taxes inclusive: ${formatPrice(car.priceExShowroom * 1.08, selectedCurrency)}`}
                        </span>
                      </div>

                      {/* Mini Compare checkbox indicator */}
                      <div className="flex items-center gap-2">
                        <label 
                          onClick={(e) => e.stopPropagation()}
                          className="flex items-center gap-1 text-[10px] font-mono text-slate-500 cursor-pointer hover:text-white"
                        >
                          <input 
                            type="checkbox" 
                            checked={compareIds.includes(car.id)}
                            onChange={(e) => toggleCompare(car.id, e)}
                            className="accent-orange-500" 
                          />
                          <span>Compare</span>
                        </label>

                        <span className="text-xs text-orange-400 font-mono flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                          Inspect Specs <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>

                    {/* AUCTION EXCLUSIVE INTERACTION */}
                    {isAuction && (
                      <div className="mt-3 pt-2.5 border-t border-white/[0.04]">
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2">
                          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-orange-500" /> Ends In:</span>
                          <span className="text-white font-bold tracking-wider">{auctionTimeLeft}</span>
                        </div>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            makeLiveBid(car.id);
                          }}
                          className="w-full py-1.5 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-mono font-black text-xs rounded-lg uppercase tracking-wider transition-all cursor-pointer shadow-md"
                        >
                          💥 Elevate Bid (+{formatPrice(car.auctionDetails?.minIncrement || 5000, selectedCurrency)})
                        </button>
                      </div>
                    )}

                  </div>

                </div>
              );
            })}
          </div>
        )}

      </main>

      {/* SHOWROOM & RATING DIRECT DIRECTORY HUB */}
      <section id="detex-showrooms" className="bg-zinc-950 py-16 border-t border-white/[0.05]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-10 gap-4">
            <div>
              <span className="text-orange-500 font-mono text-xs uppercase tracking-widest block mb-1">Direct Partners</span>
              <h2 className="text-2xl sm:text-3xl font-display font-black text-white">Verified AI Showrooms Worldwide</h2>
            </div>
            <p className="text-slate-400 text-xs sm:text-sm max-w-md font-light">
              Connect to real physical centers inside our virtual overlay. Scan showroom floor QR tags or speak directly via secure 1-click WhatsApp channels to verify models.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {showrooms.map((sr) => (
              <div 
                key={sr.id}
                onClick={() => setActiveShowroomDetails(sr)}
                className="bg-zinc-900/40 hover:bg-zinc-900 border border-white/[0.06] rounded-xl p-4 cursor-pointer transition-all hover:-translate-y-1 hover:border-[#ff5722]/30 text-left flex flex-col justify-between"
              >
                <div>
                  <div className="relative aspect-video rounded-lg overflow-hidden bg-zinc-950 mb-3.5">
                    <img 
                      src={sr.bannerImage} 
                      alt={sr.name} 
                      className="object-cover w-full h-full opacity-80"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
                    
                    {/* Tiny logo */}
                    <div className="absolute bottom-2 left-2 w-8 h-8 rounded-full border border-white/20 overflow-hidden">
                      <img src={sr.logo} alt="" className="object-cover w-full h-full" />
                    </div>
                  </div>

                  <div className="flex items-center gap-1 mb-1">
                    <div className="flex items-center text-amber-500 text-[10px]">
                      <Star className="w-3.5 h-3.5 fill-current text-amber-400" />
                      <span className="ml-1 font-bold">{sr.rating}</span>
                    </div>
                    <span className="text-[10px] text-slate-500">({sr.reviewsCount} verified reviews)</span>
                  </div>

                  <h3 className="font-display font-bold text-slate-100 text-sm hover:text-[#ff5722]">{sr.name}</h3>
                  <p className="text-[11px] font-mono text-slate-400 mt-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-orange-500" /> {sr.address}, {sr.city}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-white/[0.05] flex items-center justify-between">
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded uppercase">
                    Verification Secured
                  </span>
                  <a 
                    href={`https://wa.me/${sr.whatsapp}`} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-[10px] px-2.5 py-1 rounded"
                  >
                    <Phone className="w-2.5 h-2.5" /> Direct Call
                  </a>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* RAPID ROAD ALERT SPECIALIST GARAGES & ROAD RESCUE */}
      <section id="detex-garages" className="bg-gradient-to-b from-zinc-950 to-[#0a0a0d] py-16 border-t border-white/[0.05]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* SOS Crisis Center Red Alert Panel */}
            <div className="lg:col-span-5 bg-gradient-to-br from-red-950/80 to-zinc-950 p-6 rounded-3xl border border-red-500/20 shadow-xl space-y-4 text-left">
              <span className="px-3 py-1 bg-red-600 text-white text-[10px] font-mono font-bold tracking-widest rounded-full uppercase animate-pulse inline-block">
                💥 Emergency Rapid SOS Service
              </span>
              <h2 className="text-2xl font-display font-extrabold text-white">Locked Out or Stranded in Transit?</h2>
              <p className="text-xs text-slate-300">
                Trigger our Live Decentrahub satellite location matching system. We synchronize immediately with towing, fast-recharge grids, and diagnostic mechanics in Las Vegas, Munich, Dubai, and Tokyo 24/7.
              </p>

              <div className="p-4 bg-zinc-900/90 border border-white/10 rounded-2xl">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block mb-1">Selected Location Coordinates</span>
                <div className="bg-zinc-950 p-2.5 rounded-lg border border-white/[0.05] text-xs font-mono">
                  {sosCoords ? (
                    <span className="text-[#ff5722] font-bold tracking-wider animate-pulse">{sosCoords}</span>
                  ) : (
                    <span className="text-slate-500 italic">No coordinates registered. Tap SOS.</span>
                  )}
                </div>
              </div>

              <button 
                onClick={triggerSOSRescue}
                className={`w-full py-3 rounded-2xl font-mono text-sm font-black transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  sosStatus === 'calling' 
                  ? 'bg-amber-600 text-white animate-pulse'
                  : sosStatus === 'dispatched'
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-500/20'
                }`}
              >
                <AlertTriangle className="w-4 h-4 text-white" />
                {sosStatus === 'calling' && '🛰️ Locating Live Rescue Units...'}
                {sosStatus === 'dispatched' && '✅ Dispatch Secured! Truck is Inbound'}
                {sosStatus === 'idle' && '🚀 Activate Global SOS Instant Rescue'}
              </button>
            </div>

            {/* Specialty Tuners & Detailers */}
            <div className="lg:col-span-7 space-y-6">
              <div>
                <span className="text-indigo-400 font-mono text-xs uppercase block mb-1">Luxury Overhaul Services</span>
                <h2 className="text-2xl font-display font-black text-white">Accredited Specialization Garages</h2>
                <p className="text-xs text-slate-400">Accredited high-performance tuning, ceramic preservation detailing, and battery diagnostics.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {garages.map((g) => (
                  <div 
                    key={g.id} 
                    onClick={() => setActiveGarageDetails(g)}
                    className="p-4 bg-zinc-900/30 rounded-2xl border border-white/[0.05] hover:border-indigo-500/30 shadow-sm cursor-pointer hover:bg-zinc-900 transition-all text-left"
                  >
                    <div className="aspect-video w-full rounded-lg bg-zinc-950 overflow-hidden mb-3">
                      <img src={g.image} alt={g.name} className="object-cover w-full h-full opacity-60" />
                    </div>
                    <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest block">{g.category} Center</span>
                    <h3 className="font-display font-semibold text-xs text-white truncate mt-0.5">{g.name}</h3>
                    <div className="flex items-center gap-1 text-[10px] text-amber-500 mt-1">
                      <Star className="w-3 h-3 fill-current" />
                      <span>{g.rating} Rating</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 block">Emergency GPS: {g.emergencyRoadside ? 'Active' : 'Offline'}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* DETEX REAL-TIME TESTING DESK DASHBOARDS - SWITCHABLE ROLES */}
      <section id="detex-dashboards" className="max-w-7xl mx-auto px-4 py-16 border-t border-white/[0.06]">
        <div className="bg-zinc-900/60 p-6 rounded-3xl border border-white/[0.05]">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 pb-4 border-b border-white/[0.06] gap-4">
            <div>
              <span className="text-[#ff5722] font-mono text-xs uppercase tracking-widest block mb-1">Interactive Sandbox Environment</span>
              <h2 className="text-xl sm:text-2xl font-display font-black text-white flex items-center gap-2">
                <Store className="w-5 h-5 text-orange-500" /> Detex Platform Live Control Desk
              </h2>
            </div>

            {/* Switchers pills */}
            <div className="flex gap-1.5 p-1 bg-zinc-950 rounded-xl border border-white/10">
              {(['buyer', 'showroom', 'garage'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setActiveRole(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono cursor-pointer uppercase font-bold transition-colors ${
                    activeRole === r 
                    ? 'bg-[#ff5722] text-white' 
                    : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* 1. BUYER DASHBOARD */}
          {activeRole === 'buyer' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
              
              {/* Left Column: Registered Reservations */}
              <div className="lg:col-span-7 space-y-4">
                <h3 className="text-sm font-mono text-orange-500 uppercase font-bold">My VIP Bookings & Reservations</h3>
                {bookings.length === 0 ? (
                  <p className="text-xs text-slate-500 italic py-6 bg-zinc-950 p-4 rounded-xl">No active car reservations or test slots confirmed yet.</p>
                ) : (
                  <div className="space-y-3">
                    {bookings.map((booking) => (
                      <div key={booking.id} className="bg-zinc-950 p-4 rounded-xl border border-white/[0.05] flex justify-between items-center">
                        <div>
                          <span className="text-[10px] font-mono bg-[#ff5722]/10 text-orange-400 py-0.5 px-2 rounded uppercase font-bold">
                            {booking.type}
                          </span>
                          <h4 className="font-display font-bold text-white text-sm mt-1">{booking.carName}</h4>
                          <p className="text-[11px] text-slate-400">Showroom: {booking.showroomName}</p>
                          <p className="text-[11px] font-mono text-slate-500">Scheduled: {booking.date} at {booking.time}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-xs bg-emerald-500/10 text-emerald-400 py-1 px-3.5 rounded font-mono font-bold uppercase">
                            {booking.status}
                          </span>
                          {booking.bookingAmountPaid > 0 && (
                            <span className="block text-[10px] font-mono text-slate-400 mt-1">
                              Deposit: {formatPrice(booking.bookingAmountPaid, selectedCurrency)}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Bookmark Watchlist */}
              <div className="lg:col-span-5 space-y-4">
                <h3 className="text-sm font-mono text-orange-500 uppercase font-bold">Favorite Watchlist</h3>
                <div className="grid grid-cols-1 gap-2.5">
                  {cars.filter(c => savedCarIds.includes(c.id)).map(savedCar => (
                    <div 
                      key={savedCar.id} 
                      onClick={() => setActiveCarDetails(savedCar)}
                      className="bg-zinc-950 hover:bg-zinc-900 border border-white/[0.05] p-3 rounded-xl flex gap-3 items-center cursor-pointer transition-colors"
                    >
                      <div className="w-16 h-10 rounded bg-zinc-900 overflow-hidden">
                        <img src={savedCar.gallery[0]} className="object-cover w-full h-full" alt="" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-xs font-display font-bold text-white">{savedCar.brand} {savedCar.model}</h4>
                        <span className="text-[10px] text-orange-500 font-mono">{formatPrice(savedCar.priceExShowroom, selectedCurrency)}</span>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSaveCar(savedCar.id);
                        }}
                        className="text-[10px] text-red-400 hover:text-red-300 font-mono"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                  {savedCarIds.length === 0 && (
                    <p className="text-xs text-slate-500 py-6 text-center italic bg-zinc-950 rounded-xl">Your watchlist is currently empty.</p>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* 2. SHOWROOM SELLER DASHBOARD */}
          {activeRole === 'showroom' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
              
              {/* Inventory creation & live controls */}
              <div className="lg:col-span-7 space-y-4">
                <h3 className="text-sm font-mono text-orange-500 uppercase font-bold">Add Live Inventory Model to Vegas Hub</h3>
                <form onSubmit={handleCreateCar} className="space-y-3 bg-zinc-950 p-4 rounded-xl border border-white/[0.04]">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Brand Name</label>
                      <input 
                        type="text" 
                        required 
                        placeholder="e.g. Bugatti, Aston Martin" 
                        value={newCarForm.brand}
                        onChange={(e) => setNewCarForm(prev => ({...prev, brand: e.target.value}))}
                        className="w-full bg-zinc-900 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Model Name</label>
                      <input 
                        type="text" 
                        required 
                        placeholder="e.g. Valkyrie" 
                        value={newCarForm.model}
                        onChange={(e) => setNewCarForm(prev => ({...prev, model: e.target.value}))}
                        className="w-full bg-zinc-900 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Ex-Showroom base (USD)</label>
                      <input 
                        type="number" 
                        required 
                        value={newCarForm.priceExShowroom}
                        onChange={(e) => setNewCarForm(prev => ({...prev, priceExShowroom: Number(e.target.value)}))}
                        className="w-full bg-zinc-900 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">HP Rating</label>
                      <input 
                        type="number" 
                        required 
                        value={newCarForm.horsepower}
                        onChange={(e) => setNewCarForm(prev => ({...prev, horsepower: Number(e.target.value)}))}
                        className="w-full bg-zinc-900 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Acceleration</label>
                      <input 
                        type="text" 
                        required 
                        value={newCarForm.acceleration}
                        onChange={(e) => setNewCarForm(prev => ({...prev, acceleration: e.target.value}))}
                        className="w-full bg-zinc-900 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-2 bg-gradient-to-r from-orange-600 to-amber-600 text-white text-xs font-mono font-bold uppercase rounded cursor-pointer"
                  >
                    🚀 Instantly Sync Inventory & Air Pricing
                  </button>
                </form>

                {/* Simulated Showroom Leads capture list */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono text-slate-300 uppercase font-semibold">Incoming Buyer Requests (Automated AI Leads verification system)</h4>
                  {leads.map((ld) => (
                    <div key={ld.id} className="bg-zinc-950 p-3.5 rounded-xl border border-white/[0.05] text-xs">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-white uppercase font-display">{ld.buyerName}</span>
                        <span className="text-[10px] text-amber-500 font-mono italic">Verified Real Inquiry</span>
                      </div>
                      <p className="text-slate-400 text-xs italic">“{ld.message}”</p>
                      <div className="mt-2 text-[10px] text-slate-500 font-mono max-w-lg flex flex-wrap gap-x-4">
                        <span>Vehicle: <strong>{ld.carName}</strong></span>
                        <span>Mail: {ld.buyerEmail}</span>
                        <span>Phone: {ld.buyerPhone}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Showroom Analytics graph summary */}
              <div className="lg:col-span-5 space-y-4">
                <h3 className="text-sm font-mono text-[#ff5722] uppercase font-bold">Showroom Business Intelligence Index</h3>
                <div className="bg-zinc-950 p-4 rounded-xl border border-white/[0.04] space-y-4">
                  <p className="text-[11px] text-slate-400">Aggregated tracking for global partner model listings inside our distributed network.</p>
                  
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="bg-zinc-900/40 p-3 rounded-lg border border-white/[0.05]">
                      <span className="text-[9px] text-slate-500 block uppercase">Weekly Views</span>
                      <span className="text-lg font-mono font-bold text-slate-100">45.2k</span>
                    </div>
                    <div className="bg-zinc-900/40 p-3 rounded-lg border border-white/[0.05]">
                      <span className="text-[9px] text-slate-500 block uppercase">Conversion Ratio</span>
                      <span className="text-lg font-mono font-bold text-emerald-400">4.2%</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] text-slate-400 block font-mono">Performance indicators vs Global standard index:</span>
                    <div className="space-y-1.5 text-xs">
                      <div>
                        <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                          <span>Live Booking Conversion velocity</span>
                          <span className="text-[#ff5722]">84%</span>
                        </div>
                        <div className="w-full bg-zinc-900 rounded-full h-1.5">
                          <div className="bg-[#ff5722] h-1.5 rounded-full" style={{ width: '84%' }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                          <span>Price Integrity Accuracy index</span>
                          <span className="text-emerald-400">100% Verified</span>
                        </div>
                        <div className="w-full bg-zinc-900 rounded-full h-1.5">
                          <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '100%' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* 3. GARAGE OWNER DASHBOARD */}
          {activeRole === 'garage' && (
            <div className="text-left space-y-4">
              <h3 className="text-sm font-mono text-orange-500 uppercase font-bold">Garage Management Terminal</h3>
              <p className="text-xs text-slate-400 max-w-2xl">Handle scheduling, dynamic service packages, diagnostic codes, and respond to incoming GPS distress and towing SOS tickets instantly.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-zinc-950 p-4 rounded-xl border border-white/[0.05]">
                  <h4 className="text-xs font-mono text-slate-300 uppercase font-bold mb-3">Service Bookings & Workloads</h4>
                  <div className="space-y-2">
                    <div className="bg-zinc-900/40 p-2.5 rounded border border-white/[0.04] text-xs flex justify-between">
                      <div>
                        <span className="font-bold text-white block">Aoyama EV Battery Analysis checkup</span>
                        <span className="text-indigo-400 font-mono text-[10px]">Client: Hiroshi Tanaka</span>
                      </div>
                      <span className="text-[10px] text-amber-500 font-mono self-center">PENDING ARRIVAL</span>
                    </div>
                    <div className="bg-zinc-900/40 p-2.5 rounded border border-white/[0.04] text-xs flex justify-between">
                      <div>
                        <span className="font-bold text-white block">Bavarian Spec Carbon brake refitting</span>
                        <span className="text-indigo-400 font-mono text-[10px]">Client: Marcus G.</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono self-center">COMPLETED IN PROGRESS</span>
                    </div>
                  </div>
                </div>

                <div className="bg-zinc-950 p-4 rounded-xl border border-white/[0.05] flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-mono text-red-500 uppercase font-bold mb-3">SOS Highway Rescue Distress Log</h4>
                    {sosStatus === 'idle' ? (
                      <p className="text-xs text-slate-500 italic py-4">No active distress emergencies on local desert motorways.</p>
                    ) : (
                      <div className="space-y-2 text-xs">
                        <div className="p-2 bg-red-950/40 border border-red-500/20 rounded">
                          <span className="text-[10px] uppercase font-bold block text-red-400">ACTIVE GPS INTERCEPT SEQUENCE</span>
                          <span className="text-white block mt-1">Coordinates: {sosCoords}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">Status: Outbound rescue response initiated.</span>
                        </div>
                      </div>
                    )}
                  </div>
                  <div>
                    <button 
                      onClick={() => setSosStatus('idle')}
                      className="w-full py-1.5 bg-zinc-900 hover:bg-zinc-800 text-xs font-mono text-slate-300 rounded"
                    >
                      Clear/Acknowledge distress tickets
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </section>

      {/* FOOTER DESIGNS */}
      <footer id="detex-footer" className="bg-zinc-950 py-12 border-t border-white/[0.08] text-xs font-mono text-slate-500">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-4 gap-8 mb-8 text-left">
          
          <div className="space-y-2">
            <span className="block font-display font-black text-white text-base tracking-widest text-[#ff5722]">DETEX AUTO</span>
            <p className="font-sans leading-relaxed text-slate-400">
              The premier hyper-ecosystem bridging elite visual showrooms from Las Vegas, Munich, Dubai, and Tokyo seamlessly inside our smart transaction grid.
            </p>
          </div>

          <div>
            <h4 className="text-slate-300 uppercase font-black text-xs mb-3">Region Hubs</h4>
            <ul className="space-y-1.5">
              <li>📍 Las Vegas (Aether Motorsports Hub)</li>
              <li>📍 Tokyo (Apex Electric Arena)</li>
              <li>📍 Munich (Bavarian Performance Corp)</li>
              <li>📍 Dubai (Gulf Custom Superlounge)</li>
            </ul>
          </div>

          <div>
            <h4 className="text-slate-300 uppercase font-black text-xs mb-3">Distributed Tech</h4>
            <ul className="space-y-1.5">
              <li>Gemini-3.5-Flash</li>
              <li>Dual Node REST Endpoints</li>
              <li>Secure SSL Tunnel verification</li>
              <li>Local Wallet Index</li>
            </ul>
          </div>

          <div>
            <h4 className="text-slate-300 uppercase font-black text-xs mb-3">Developer Settings</h4>
            <p className="font-sans text-slate-400 mb-2">Simulate cross-domain Webhook transmissions by clicking theforced synchronized widgets.</p>
            <span className="block text-[#ff5722] font-semibold text-[10px]">VERNO NO: 2.08.1-BETA</span>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-4 pt-6 border-t border-white/[0.04] text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <span>© 2026 DETEX AUTO GLOBAL PARTNERS. All physical allocations secured by secure legal ESCROW protocols.</span>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer">Security Protocol</span>
            <span className="hover:text-white cursor-pointer">Dealer Escrow Contract</span>
            <span className="hover:text-white cursor-pointer">Terms of System Usage</span>
          </div>
        </div>
      </footer>

      {/* ————————————————— 1. DYNAMIC DETAIL MODAL SHOWCASE ————————————————— */}
      {activeCarDetails && (
        <div id="car-details-modal" className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/10 rounded-3xl w-full max-w-5xl overflow-hidden shadow-2xl block text-left my-8 max-h-[90vh] overflow-y-auto">
            
            {/* Modal header with title & controls */}
            <div className="p-6 border-b border-white/[0.08] flex items-center justify-between sticky top-0 bg-zinc-900 z-10">
              <div>
                <span className="text-xs font-mono text-orange-500 uppercase tracking-widest block mb-0.5">Verified Partner Hub: {activeCarDetails.showroomName}</span>
                <h2 className="text-2xl font-display font-black text-white">{activeCarDetails.brand} {activeCarDetails.model}</h2>
              </div>
              <button 
                onClick={() => {
                  setActiveCarDetails(null);
                  setResalePredictions([]);
                  setResaleSynopsis('');
                }}
                className="p-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main content grid */}
            <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Column: Interactive Immersive 360 Viewer & gallery */}
              <div className="lg:col-span-6 space-y-6">
                
                {/* Simulated Interactive 360 Viewer */}
                <div className="bg-zinc-950 rounded-2xl p-4 border border-white/[0.05] relative">
                  <span className="absolute top-3 left-3 bg-zinc-900/90 py-1 px-2.5 rounded text-[9px] font-mono text-orange-400 border border-white/5 uppercase">
                    📸 Interactive 360° Studio Mode
                  </span>
                  
                  {/* Outer Frame preview representing angle changes */}
                  <div className="aspect-video w-full overflow-hidden rounded-xl bg-zinc-900 mt-6 relative flex items-center justify-center">
                    <img 
                      src={activeCarDetails.gallery[viewerAngle % activeCarDetails.gallery.length] || activeCarDetails.gallery[0]} 
                      alt="" 
                      className="object-cover w-full h-full opacity-90 transition-all duration-300"
                    />
                    
                    {/* Perspective lines */}
                    <div className="absolute bottom-2 inset-x-0 text-center">
                      <span className="bg-black/85 text-[10px] font-mono py-1 px-3 rounded-full text-slate-300 border border-white/10">
                        Horizontal camera position index: <strong>{viewerAngle * 45}° Perspective Layout</strong>
                      </span>
                    </div>
                  </div>

                  {/* Range Slider for simulating manual rotating angle */}
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono text-slate-400">
                      <span>Drag to pan interior/exterior perspective</span>
                      <span className="text-orange-500 font-bold">Pan active</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="7" 
                      value={viewerAngle}
                      onChange={(e) => setViewerAngle(Number(e.target.value))}
                      className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-[#ff5722]" 
                    />
                  </div>

                  <span className="text-[10px] text-slate-500 font-mono block text-center mt-2">
                    (Simulates full VR immersive alignment. Verified dynamically by showroom telemetry daemon.)
                  </span>
                </div>

                {/* Quick Spec list */}
                <div className="bg-zinc-950 p-4 rounded-xl border border-white/[0.04] space-y-2">
                  <h4 className="text-xs font-mono text-slate-300 uppercase font-bold">Standard Mechanics specifications</h4>
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div className="flex justify-between border-b border-white/[0.04] pb-1.5">
                      <span className="text-slate-500">Powertrain</span>
                      <span className="text-white font-mono">{activeCarDetails.mileage.includes('hybrid') ? 'Hybrid Hybrid' : activeCarDetails.mileage.includes('Electric') ? 'Electric' : 'Mechanical ICE'}</span>
                    </div>
                    <div className="flex justify-between border-b border-white/[0.04] pb-1.5">
                      <span className="text-slate-500">Class Rating</span>
                      <span className="text-white font-mono">{activeCarDetails.category}</span>
                    </div>
                    <div className="flex justify-between border-b border-white/[0.04] pb-1.5">
                      <span className="text-slate-500">Top speed</span>
                      <span className="text-white font-mono">{activeCarDetails.topSpeed} km/h</span>
                    </div>
                    <div className="flex justify-between border-b border-white/[0.04] pb-1.5">
                      <span className="text-slate-500">Acceleration</span>
                      <span className="text-white font-mono">{activeCarDetails.acceleration}</span>
                    </div>
                  </div>
                </div>

                {/* AI generated Pros & Cons mapping */}
                <div className="bg-zinc-950/50 p-4 rounded-xl border border-white/[0.04] space-y-3">
                  <h4 className="text-xs font-mono text-orange-400 uppercase font-bold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" /> AI-Generated Professional Pros & Cons Guidance
                  </h4>
                  <div className="space-y-2 text-xs">
                    {activeCarDetails.pros && (
                      <div>
                        <span className="font-bold text-emerald-400 block mb-0.5">✓ Engineering Advantages</span>
                        <ul className="list-disc pl-4 space-y-1 text-slate-300">
                          {activeCarDetails.pros.map((p, i) => <li key={i}>{p}</li>)}
                        </ul>
                      </div>
                    )}
                    {activeCarDetails.cons && (
                      <div className="mt-2.5">
                        <span className="font-bold text-amber-500 block mb-0.5">⚠ Operational Drawbacks</span>
                        <ul className="list-disc pl-4 space-y-1 text-slate-300">
                          {activeCarDetails.cons.map((c, i) => <li key={i}>{c}</li>)}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Right Column: Loan Calculator, Local Taxes on Road, Live Predictions, and Book Options */}
              <div className="lg:col-span-6 space-y-6">
                
                {/* On road calculated pricing dashboard with variables */}
                <div className="bg-zinc-950 p-5 rounded-2xl border border-white/[0.05] space-y-3">
                  <div className="flex justify-between items-center pb-2 border-b border-white/[0.06]">
                    <span className="text-xs font-mono text-slate-400 uppercase">On-Road local registration pricing</span>
                    <span className="px-2 py-0.5 text-[9px] font-mono text-orange-400 bg-orange-500/10 rounded">
                      Local taxes index mapping
                    </span>
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Ex-Showroom Price</span>
                      <span className="text-white font-bold">{formatPrice(activeCarDetails.priceExShowroom, selectedCurrency)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Country Regional Tax rate ({activeCarDetails.country === 'Germany' ? '19%' : activeCarDetails.country === 'Japan' ? '10%' : '8%'})</span>
                      <span className="text-slate-300">{formatPrice(getTaxesDetail(activeCarDetails).taxes, selectedCurrency)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Insurance Premium estimate (Annual)</span>
                      <span className="text-slate-300">{formatPrice(activeCarDetails.insuranceEstimate, selectedCurrency)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Dealer registration files & delivery</span>
                      <span className="text-slate-300">{formatPrice(getTaxesDetail(activeCarDetails).regFee, selectedCurrency)}</span>
                    </div>

                    <div className="flex justify-between pt-2.5 border-t border-white/[0.08] text-sm text-white font-bold">
                      <span className="text-[#ff5722] uppercase tracking-wider font-display">On-Road Estimated total</span>
                      <span className="text-orange-400">{formatPrice(getTaxesDetail(activeCarDetails).onRoadEst, selectedCurrency)}</span>
                    </div>
                  </div>
                </div>

                {/* 2. LIVE EMI CALCULATOR SLIDERS */}
                <div className="bg-zinc-950 p-5 rounded-2xl border border-white/[0.05] space-y-4">
                  <h4 className="text-xs font-mono text-slate-300 uppercase font-black flex items-center gap-1">
                    <Calculator className="w-4 h-4 text-[#ff5722]" /> Real-time Interactive EMI financing calculator
                  </h4>

                  <div className="space-y-3 text-xs">
                    
                    {/* Down payment slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-400">
                        <span>Initial Down Payment Percent</span>
                        <span className="text-slate-200 font-mono font-bold">{downPaymentPercent}% ({formatPrice(activeCarDetails.priceExShowroom * (downPaymentPercent/100), selectedCurrency)})</span>
                      </div>
                      <input 
                        type="range" 
                        min="10" 
                        max="80" 
                        step="5"
                        value={downPaymentPercent} 
                        onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                        className="w-full accent-[#ff5722]" 
                      />
                    </div>

                    {/* Loan periods slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-400">
                        <span>Loan Repayment duration</span>
                        <span className="text-slate-200 font-mono font-bold">{loanTerm} Months ({Math.round(loanTerm/12)} years)</span>
                      </div>
                      <input 
                        type="range" 
                        min="24" 
                        max="84" 
                        step="12"
                        value={loanTerm} 
                        onChange={(e) => setLoanTerm(Number(e.target.value))}
                        className="w-full accent-[#ff5722]" 
                      />
                    </div>

                    {/* Interest rates */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-400">
                        <span>Interest Profile rate (Compounded Annually)</span>
                        <span className="text-slate-200 font-mono font-bold">{loanInterest}% rate</span>
                      </div>
                      <input 
                        type="range" 
                        min="2.5" 
                        max="12.0" 
                        step="0.1"
                        value={loanInterest} 
                        onChange={(e) => setLoanInterest(Number(e.target.value))}
                        className="w-full accent-[#ff5722]" 
                      />
                    </div>

                    {/* Computed output values */}
                    {(() => {
                      const principal = activeCarDetails.priceExShowroom * (1 - (downPaymentPercent / 100));
                      const monthlyRate = (loanInterest / 100) / 12;
                      const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, loanTerm)) / (Math.pow(1 + monthlyRate, loanTerm) - 1);
                      return (
                        <div className="bg-zinc-900/80 p-3.5 rounded-xl border border-white/[0.04] flex items-center justify-between mt-3 font-mono">
                          <div>
                            <span className="block text-[8px] text-slate-500 uppercase">Computed Monthly EMI</span>
                            <span className="text-base font-bold text-orange-400">{formatPrice(isNaN(emi) ? 0 : emi, selectedCurrency)}/mo</span>
                          </div>
                          <div className="text-right">
                            <span className="block text-[8px] text-slate-500 uppercase">Calculated principal loan</span>
                            <span className="text-xs text-slate-300">{formatPrice(principal, selectedCurrency)}</span>
                          </div>
                        </div>
                      );
                    })()}

                  </div>
                </div>

                {/* 3. GEMINI RESALE FORRECAST VISUALIZER */}
                <div className="bg-gradient-to-br from-zinc-950 to-zinc-900 p-5 rounded-2xl border border-[#ff5722]/20 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-orange-400 flex items-center gap-1 font-bold">
                      <Sparkles className="w-4 h-4" /> AI Asset Resale Prediction Tracker
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">5-Year Valuation Grid</span>
                  </div>

                  {resaleLoading ? (
                    <div className="py-12 text-center text-xs font-mono text-slate-400 animate-pulse">
                      Analyzing historic pricing velocity via AI core nodes...
                    </div>
                  ) : (
                    <>
                      {/* High Tech Glowing Vector SVG Chart */}
                      {resalePredictions.length > 0 && (
                        <div className="bg-zinc-950 p-3 rounded-xl border border-white/[0.04]">
                          <span className="text-[9px] font-mono text-slate-500 uppercase block mb-2">Calculated asset asset progression curve</span>
                          
                          {/* Visual Graph container */}
                          <div className="h-28 w-full flex items-end justify-between gap-2 pt-4 relative">
                            {resalePredictions.map((pred, idx) => {
                              const heightPercent = Math.max(20, Math.round(pred.percentage));
                              return (
                                <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full group/bar">
                                  <span className="text-[9px] text-[#ff5722] font-mono font-bold mb-1 opacity-0 group-hover/bar:opacity-100 transition-opacity">
                                    {pred.percentage}%
                                  </span>
                                  <div 
                                    className="w-full rounded-t bg-gradient-to-t from-[#ff5722]/30 to-[#ff5722] relative group-hover/bar:brightness-125 transition-all cursor-pointer" 
                                    style={{ height: `${heightPercent * 0.7}%` }}
                                  >
                                    <div className="absolute top-0 left-0 right-0 h-1 bg-orange-400 hover:glow-orange shrink-0 blur-[1px]" />
                                  </div>
                                  <span className="text-[10px] text-slate-400 font-mono mt-2">Yr {pred.year}</span>
                                </div>
                              );
                            })}
                          </div>

                          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 border-t border-white/[0.05] mt-3.5 pt-2">
                            <span>Initial value: {formatPrice(activeCarDetails.priceExShowroom, selectedCurrency)}</span>
                            <span className="text-orange-400">Year 5: {formatPrice(resalePredictions[4]?.valueUsd || 0, selectedCurrency)}</span>
                          </div>
                        </div>
                      )}

                      {resaleSynopsis && (
                        <p className="text-xs text-slate-300 font-light italic leading-relaxed bg-[#ff5722]/5 p-3 rounded-lg border border-[#ff5722]/10">
                          “{resaleSynopsis}”
                        </p>
                      )}
                    </>
                  )}
                </div>

                {/* primary buttons for booking */}
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setCheckoutBooking({ car: activeCarDetails, type: 'test' })}
                    className="w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-mono font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer"
                  >
                    📅 Schedule VIP Test Drive
                  </button>
                  <button 
                    onClick={() => setCheckoutBooking({ car: activeCarDetails, type: 'reserve' })}
                    className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-mono font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer shadow-lg glow-orange"
                  >
                    🛒 Place Reservation Deposit
                  </button>
                </div>

              </div>
              
            </div>

          </div>
        </div>
      )}

      {/* ————————————————— 2. SHOWROOM MINI WEB PROFILE MODAL ————————————————— */}
      {activeShowroomDetails && (
        <div id="showroom-profile-modal" className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/10 rounded-2xl w-full max-w-4xl overflow-hidden block text-left">
            
            {/* Banner element */}
            <div className="relative aspect-video max-h-56 bg-zinc-950 w-full overflow-hidden">
              <img src={activeShowroomDetails.bannerImage} className="object-cover w-full h-full opacity-70" alt="" />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent" />
              <button 
                onClick={() => setActiveShowroomDetails(null)}
                className="absolute top-4 right-4 p-2 bg-black/80 rounded-full text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full overflow-hidden border border-white/20 bg-zinc-950 -mt-12 relative z-10 shadow-lg">
                  <img src={activeShowroomDetails.logo} alt="" className="object-cover w-full h-full" />
                </div>
                <div>
                  <h3 className="text-xl font-display font-black text-white">{activeShowroomDetails.name}</h3>
                  <span className="text-xs font-mono text-emerald-400">● REAL-TIME DIRECT INTEGRATION ACTIVE</span>
                </div>
              </div>

              {/* Grid content */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* Contact profiles */}
                <div className="md:col-span-4 space-y-4 text-xs">
                  <div className="bg-zinc-950 p-4 rounded-xl border border-white/[0.04] space-y-2">
                    <span className="font-mono text-slate-400 uppercase tracking-widest block text-[10px]">Registry metadata</span>
                    <p className="text-slate-300"><strong>Hub location:</strong> {activeShowroomDetails.address}, {activeShowroomDetails.city}</p>
                    <p className="text-slate-300"><strong>Corporate mail:</strong> {activeShowroomDetails.email}</p>
                    <p className="text-slate-300"><strong>Direct Helpline:</strong> {activeShowroomDetails.phone}</p>
                  </div>

                  <a 
                    href={`https://wa.me/${activeShowroomDetails.whatsapp}`}
                    target="_blank"
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 rounded text-center text-white font-mono font-bold block"
                  >
                    💬 Launch Verified WhatsApp Chat
                  </a>
                </div>

                {/* Showroom local listings info */}
                <div className="md:col-span-8 space-y-4">
                  <h4 className="text-xs font-mono text-orange-500 uppercase font-black">Active Marketplace Allocations ({cars.filter(c => c.showroomId === activeShowroomDetails.id).length})</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {cars.filter(c => c.showroomId === activeShowroomDetails.id).map(cModel => (
                      <div 
                        key={cModel.id}
                        onClick={() => {
                          setActiveCarDetails(cModel);
                          setActiveShowroomDetails(null);
                        }}
                        className="bg-zinc-950 p-3 rounded-lg border border-white/[0.05] hover:border-orange-500/20 cursor-pointer text-xs"
                      >
                        <span className="block text-white font-bold">{cModel.brand} {cModel.model}</span>
                        <span className="font-mono text-orange-500">{formatPrice(cModel.priceExShowroom, selectedCurrency)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Reviews */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono text-slate-500 uppercase">Customer feedback logs</span>
                    {activeShowroomDetails.reviews.map((r, i) => (
                      <div key={i} className="bg-zinc-950/40 p-3 rounded-xl border border-white/[0.03]">
                        <span className="font-bold text-white block">{r.userName}</span>
                        <p className="text-slate-300 italic">{r.comment}</p>
                        <span className="text-[9px] text-slate-500 font-mono mt-1 block">{r.date}</span>
                      </div>
                    ))}
                    {activeShowroomDetails.reviews.length === 0 && (
                      <p className="text-xs text-slate-600 italic">No feedback posts yet. Complete booking to submit a rating.</p>
                    )}
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      )}

      {/* ————————————————— 3. GARAGE EXCLUSIVE DETAILS MODAL ————————————————— */}
      {activeGarageDetails && (
        <div id="garage-details-modal" className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/10 rounded-2xl w-full max-w-3xl overflow-hidden block text-left">
            
            <div className="p-6 border-b border-white/[0.08] flex items-center justify-between">
              <div>
                <span className="text-xs font-mono text-indigo-400 uppercase tracking-widest block mb-0.5">Accredited Specialization Facility</span>
                <h3 className="text-xl font-display font-black text-white">{activeGarageDetails.name}</h3>
              </div>
              <button onClick={() => setActiveGarageDetails(null)} className="p-1 rounded-full bg-zinc-800 text-slate-300">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-6">
                
                <div className="sm:col-span-4 rounded-xl overflow-hidden aspect-video sm:aspect-square bg-zinc-950">
                  <img src={activeGarageDetails.image} className="object-cover w-full h-full" alt="" />
                </div>

                <div className="sm:col-span-8 space-y-4 text-xs">
                  <div className="bg-zinc-950 p-4 rounded-xl space-y-2 border border-white/[0.03]">
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">Facility registry</span>
                    <p className="text-slate-300"><strong>City Station:</strong> {activeGarageDetails.city}, {activeGarageDetails.country}</p>
                    <p className="text-slate-300"><strong>Address:</strong> {activeGarageDetails.address}</p>
                    <p className="text-slate-300"><strong>24/7 Towing SOS:</strong> {activeGarageDetails.emergencyRoadside ? 'Enabled Grid' : 'Standard business timings'}</p>
                  </div>

                  <h4 className="text-xs font-mono text-indigo-400 uppercase font-bold">Standard service specifications & tuning packages</h4>
                  <div className="space-y-2">
                    {activeGarageDetails.services.map((svc, idx) => (
                      <div key={idx} className="bg-zinc-950 p-3 rounded-lg border border-white/[0.04]">
                        <div className="flex justify-between font-bold text-white">
                          <span>{svc.name}</span>
                          <span className="text-indigo-400">{formatPrice(svc.price, selectedCurrency)}</span>
                        </div>
                        <p className="text-slate-400 font-light mt-0.5">{svc.description}</p>
                        <span className="text-[10px] text-slate-500 block font-mono">Completion: {svc.duration}</span>
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => {
                      alert("Service appointment successfully scheduled. Diagnostic tickets generated and transmitted to garage terminal.");
                      setActiveGarageDetails(null);
                    }}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs uppercase"
                  >
                    📅 Dispatch VIP Service Slot Appointment
                  </button>
                </div>

              </div>
            </div>

          </div>
        </div>
      )}

      {/* ————————————————— 4. SECURE STRIPE CHECKOUT MODAL ————————————————— */}
      {checkoutBooking && (
        <div id="payment-overlay" className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/15 rounded-3xl p-6 w-full max-w-md block text-left space-y-5 relative">
            
            {transactionSuccess ? (
              <div className="py-8 text-center space-y-3">
                <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto animate-bounce" />
                <h3 className="text-xl font-display font-black text-white uppercase tracking-tight">Escrow Deposit Confirmed</h3>
                <p className="text-xs text-slate-400">Transaction secured by platform SSL protocol. VIP allocation ticket mapped to your buyer dashboard accounts.</p>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-center pb-3 border-b border-white/[0.08]">
                  <h3 className="text-base font-display font-bold text-white uppercase tracking-wider">
                    {checkoutBooking.type === 'reserve' ? '🛒 Secure Escrow Reservation' : '📅 Book VIP Track Test'}
                  </h3>
                  <button onClick={() => setCheckoutBooking(null)} className="text-slate-400 hover:text-white cursor-pointer">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="bg-zinc-950 p-3.5 rounded-xl text-xs space-y-2 border border-white/[0.05]">
                  <span className="text-[9px] font-mono text-slate-500 uppercase block">Selected Model Allocation</span>
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-9 rounded bg-zinc-900 overflow-hidden">
                      <img src={checkoutBooking.car.gallery[0] || ''} className="object-cover w-full h-full" alt="" />
                    </div>
                    <div>
                      <span className="font-display font-bold text-white text-sm block">{checkoutBooking.car.brand} {checkoutBooking.car.model}</span>
                      <span className="text-[11px] text-[#ff5722] font-mono">{formatPrice(checkoutBooking.car.priceExShowroom, selectedCurrency)}</span>
                    </div>
                  </div>
                </div>

                <form onSubmit={proceedShowroomReservation} className="space-y-3.5 text-xs">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 font-mono block mb-1">Select booking date</label>
                      <input 
                        type="date" 
                        required 
                        value={checkoutDate}
                        onChange={(e) => setCheckoutDate(e.target.value)}
                        className="w-full bg-zinc-950 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-mono block mb-1">Select schedule hour</label>
                      <input 
                        type="time" 
                        required 
                        value={checkoutTime}
                        onChange={(e) => setCheckoutTime(e.target.value)}
                        className="w-full bg-zinc-950 border border-white/10 rounded p-1.5 text-xs text-white" 
                      />
                    </div>
                  </div>

                  {checkoutBooking.type === 'reserve' && (
                    <div className="bg-zinc-950/80 p-3.5 rounded-xl border border-white/[0.06] space-y-2">
                      <div className="flex justify-between font-mono font-bold text-white">
                        <span>Platform Escrow Deposit</span>
                        <span className="text-[#ff5722]">{formatPrice(5000, selectedCurrency)}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-normal">
                        Your deposit resides in secure escrow until identity and vehicle parameters are validated on physical showroom arrival. Completely refundable up until 24 hours prior.
                      </p>
                    </div>
                  )}

                  <div className="bg-[#ff5722]/5 p-3 rounded-lg border border-[#ff5722]/15 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span className="text-[10px] text-slate-300 leading-tight">
                      Stripe secured overlay. Complete address validation code verified dynamically.
                    </span>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 text-white font-mono font-black text-xs uppercase tracking-wider rounded"
                  >
                    💳 Commit Escrow Reservation
                  </button>
                </form>
              </>
            )}

          </div>
        </div>
      )}

      {/* ————————————————— 5. SIDE-BY-SIDE SPEC COMPARE MODAL ————————————————— */}
      {showCompareModal && compareIds.length >= 1 && (
        <div id="compare-modal" className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/10 rounded-2xl p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto block text-left space-y-6">
            
            <div className="flex justify-between items-center border-b border-white/[0.08] pb-4">
              <h3 className="text-xl font-display font-black text-white flex items-center gap-2">
                <ArrowLeftRight className="w-5 h-5 text-orange-500" /> Side-by-Side Spec Comparison Lounge
              </h3>
              <button onClick={() => setShowCompareModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 border-b border-white/[0.08] pb-4">
              
              {/* Labels column */}
              <div className="space-y-4 self-end text-slate-500 text-xs font-mono uppercase">
                <div>Model Specs</div>
                <div className="pt-2 border-t border-white/[0.03]">Category / Grade</div>
                <div className="pt-2 border-t border-white/[0.03]">Base price</div>
                <div className="pt-2 border-t border-white/[0.03]">Raw Horsepower</div>
                <div className="pt-2 border-t border-white/[0.03]">Acceleration index</div>
                <div className="pt-2 border-t border-white/[0.03]">Peak Velocity</div>
                <div className="pt-2 border-t border-white/[0.03]">Fuel Powertrain</div>
              </div>

              {/* Vehicle 1 */}
              {(() => {
                const c1 = cars.find(c => c.id === compareIds[0]);
                if (!c1) return <div className="text-xs text-slate-500 italic">Deselected model</div>;
                return (
                  <div className="p-4 bg-zinc-950 rounded-xl space-y-4 text-xs font-mono">
                    <div>
                      <h4 className="font-display font-bold text-sm text-white">{c1.brand}</h4>
                      <span className="text-slate-400">{c1.model} ({c1.year})</span>
                    </div>
                    
                    <div className="pt-2 border-t border-white/[0.03]">{c1.category} / {c1.condition}</div>
                    <div className="pt-2 border-t border-white/[0.03] text-orange-400 font-bold">{formatPrice(c1.priceExShowroom, selectedCurrency)}</div>
                    <div className="pt-2 border-t border-white/[0.03] text-white font-bold">{c1.horsepower} HP</div>
                    <div className="pt-2 border-t border-white/[0.03] text-white">{c1.acceleration}</div>
                    <div className="pt-2 border-t border-white/[0.03] text-white">{c1.topSpeed} km/h</div>
                    <div className="pt-2 border-t border-white/[0.03] text-slate-300 truncate">{c1.mileage}</div>
                  </div>
                );
              })()}

              {/* Vehicle 2 */}
              {(() => {
                const c2 = cars.find(c => c.id === compareIds[1]);
                if (!c2) {
                  return (
                    <div className="bg-zinc-950/40 border border-dashed border-white/10 rounded-xl p-6 flex flex-col items-center justify-center text-center">
                      <p className="text-xs text-slate-500 italic">Select one more car card compare checkboxes to fill slot.</p>
                      <button 
                        onClick={() => setShowCompareModal(false)}
                        className="mt-3 py-1 px-3 bg-zinc-905 bg-zinc-800 text-slate-300 text-[10px] rounded uppercase font-mono"
                      >
                        Browse Models
                      </button>
                    </div>
                  );
                }
                return (
                  <div className="p-4 bg-zinc-905 bg-zinc-950 rounded-xl space-y-4 text-xs font-mono">
                    <div>
                      <h4 className="font-display font-bold text-sm text-white">{c2.brand}</h4>
                      <span className="text-slate-400">{c2.model} ({c2.year})</span>
                    </div>
                    
                    <div className="pt-2 border-t border-white/[0.03]">{c2.category} / {c2.condition}</div>
                    <div className="pt-2 border-t border-white/[0.03] text-orange-400 font-bold">{formatPrice(c2.priceExShowroom, selectedCurrency)}</div>
                    <div className="pt-2 border-t border-white/[0.03] text-white font-bold">{c2.horsepower} HP</div>
                    <div className="pt-2 border-t border-white/[0.03] text-white">{c2.acceleration}</div>
                    <div className="pt-2 border-t border-white/[0.03] text-white">{c2.topSpeed} km/h</div>
                    <div className="pt-2 border-t border-white/[0.03] text-slate-300 truncate">{c2.mileage}</div>
                  </div>
                );
              })()}

            </div>

            <div className="flex gap-2.5 justify-end">
              <button 
                onClick={() => setCompareIds([])}
                className="py-1 px-4 bg-zinc-800 hover:bg-zinc-700 text-white font-mono text-xs rounded"
              >
                Clear comparison selection
              </button>
              <button 
                onClick={() => setShowCompareModal(false)}
                className="py-1 px-4 bg-gradient-to-r from-orange-600 to-amber-600 text-white font-mono text-xs rounded"
              >
                Return to grids
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ————————————————— 6. PHYSICAL FLOOR DEALS QR SIMULATOR ————————————————— */}
      {qrCodeModal && (
        <div id="qr-modal" className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/10 rounded-2xl p-6 w-full max-w-sm text-center space-y-4">
            <h3 className="font-display font-black text-white text-base uppercase tracking-wider">Showroom QR Portal</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Scan simulated code to bridge on-site showroom test-drives with platform exclusive client incentives! Click an entity model below to execute a mock scan sequence.
            </p>

            <div className="bg-white p-4 max-w-xs mx-auto rounded-xl flex items-center justify-center">
              {/* Representing a mockup QR code using vector box elements */}
              <div className="grid grid-cols-4 gap-2 w-28 h-28 bg-white border border-slate-300 p-2">
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-300 rounded" />
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-300 rounded" />
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-300 rounded" />
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-300 rounded" />
                <div className="bg-slate-900 rounded" />
                <div className="bg-slate-900 rounded" />
              </div>
            </div>

            <div className="space-y-2 mt-4">
              <span className="text-[10px] font-mono text-slate-500 uppercase block">Simulate scanning showroom floor:</span>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <button 
                  onClick={() => handleSimulateQRScan('Aether Vegas')}
                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded text-slate-200"
                >
                  Aether Las Vegas
                </button>
                <button 
                  onClick={() => handleSimulateQRScan('Tokyo Apex Hub')}
                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded text-slate-200"
                >
                  Tokyo Electric Hub
                </button>
              </div>
            </div>

            <button onClick={() => setQrCodeModal(false)} className="text-xs text-slate-500 uppercase underline block mx-auto">
              Cancel Simulator
            </button>
          </div>
        </div>
      )}

      {/* ————————————————— 7. FLOATING DETEX AI CO-PILOT SLIDE-PANEL ————————————————— */}
      {chatOpen && (
        <div id="ai-chat-panel" className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-zinc-900 border-l border-white/10 shadow-2xl flex flex-col justify-between overflow-hidden">
          
          {/* Header */}
          <div className="p-4 bg-zinc-950 border-b border-white/[0.08] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 bg-orange-500 rounded-full animate-ping" />
              <div>
                <span className="block text-xs font-mono text-orange-500 font-bold uppercase tracking-wider">Detex AI Copilot Assistant</span>
                <span className="block text-[9px] text-slate-400">Gemini-3.5-Flash</span>
              </div>
            </div>
            <button 
              onClick={() => setChatOpen(false)}
              className="p-1 rounded-full bg-zinc-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages stream */}
          <div className="p-4 flex-1 overflow-y-auto space-y-4 font-mono text-xs">
            {chatMessages.map((msg) => (
              <div 
                key={msg.id}
                className={`p-3 rounded-xl max-w-[85%] ${
                  msg.sender === 'user' 
                  ? 'bg-[#ff5722] text-white ml-auto' 
                  : 'bg-zinc-950 border border-white/[0.05] text-slate-100 mr-auto font-light leading-relaxed'
                }`}
              >
                {/* Handled simple bolding syntax manually or raw text blocks */}
                <p className="whitespace-pre-wrap">{msg.text.replace(/\*\*/g, '')}</p>
                <span className={`block text-[9px] mt-1 text-right ${msg.sender === 'user' ? 'text-orange-200' : 'text-slate-500'}`}>
                  {msg.timestamp}
                </span>
              </div>
            ))}
            {chatLoading && (
              <div className="p-2 bg-zinc-950/60 rounded text-[10px] text-slate-500 mr-auto animate-pulse italic">
                Scanning engine specifications and matching future valuations...
              </div>
            )}
          </div>

          {/* Quick chip inputs */}
          <div className="p-2.5 bg-zinc-950 border-t border-white/[0.05] flex gap-1.5 overflow-x-auto scrollbar-none">
            <button 
              onClick={() => handleSendChat("Predict resale of Lamborghini Revuelto")}
              className="px-2.5 py-1 rounded bg-zinc-900 border border-white/10 hover:border-[#ff5722]/50 text-slate-300 whitespace-nowrap text-[9px] cursor-pointer"
            >
              📈 Predictive Resale
            </button>
            <button 
              onClick={() => handleSendChat("Which EV charger setup delivers 800V support?")}
              className="px-2.5 py-1 rounded bg-zinc-900 border border-white/10 hover:border-[#ff5722]/50 text-slate-300 whitespace-nowrap text-[9px] cursor-pointer"
            >
              🔌 EV charging tech
            </button>
            <button 
              onClick={() => handleSendChat("Compare Porsche Taycan with Tesla Plaid specs")}
              className="px-2.5 py-1 rounded bg-zinc-900 border border-white/10 hover:border-[#ff5722]/50 text-slate-300 whitespace-nowrap text-[9px] cursor-pointer"
            >
              ⚖ Compare performance
            </button>
          </div>

          {/* Form input */}
          <div className="p-3 bg-zinc-950/90 border-t border-white/[0.08] flex gap-2">
            <input 
              type="text" 
              placeholder="Ask Detex AI..." 
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
              className="flex-grow bg-zinc-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
            />
            <button 
              onClick={() => handleSendChat()}
              className="bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-mono font-bold text-xs uppercase px-4 rounded-xl cursor-pointer"
            >
              Send
            </button>
          </div>

        </div>
      )}

    </div>
  );
}
