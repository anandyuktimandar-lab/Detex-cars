export type UserRole = 'buyer' | 'seller' | 'showroom' | 'garage' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: UserRole;
  phone?: string;
  showroomName?: string;
  garageName?: string;
  selectedCurrency: 'USD' | 'EUR' | 'INR' | 'AED' | 'GBP';
  savedCars: string[]; // Car IDs
  showroomLeads?: Lead[];
}

export interface Lead {
  id: string;
  carId: string;
  carName: string;
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  message: string;
  status: 'pending' | 'contacted' | 'resolved';
  date: string;
}

export interface Showroom {
  id: string;
  name: string;
  logo: string;
  bannerImage: string;
  verified: boolean;
  address: string;
  city: string;
  country: string;
  phone: string;
  whatsapp: string;
  email: string;
  socials: {
    instagram?: string;
    twitter?: string;
    facebook?: string;
  };
  rating: number;
  reviewsCount: number;
  reviews: Review[];
  featuredModels: string[]; // Car IDs
  analytics: {
    monthlyViews: number;
    leadsGenerated: number;
    activeCars: number;
    conversionRate: number; // percentage
  };
}

export interface Car {
  id: string;
  brand: string;
  model: string;
  year: number;
  category: 'New' | 'Used' | 'Luxury' | 'EV' | 'Auction';
  condition: 'New' | 'Certified' | 'Used';
  priceExShowroom: number; // Base USD price
  priceOnRoad: number;
  emiBase: number; // Monthly USD
  whatsapp: string;
  insuranceEstimate: number;
  showroomId: string; // Connected showroom
  showroomName: string;
  mileage: string; // e.g. "12.5 km/l" or "450 km range"
  topSpeed: number; // km/h
  horsepower: number;
  torque: number; // Nm
  acceleration: string; // e.g. "3.2s"
  safetyRating: number; // out of 5
  gallery: string[]; // Image URLs
  colors: { name: string; hex: string }[];
  availability: 'In Stock' | 'Delayed' | 'Pre-Order Only' | 'Sold Out';
  city: string;
  country: string;
  pros: string[];
  cons: string[];
  auctionDetails?: {
    currentBid: number;
    minIncrement: number;
    endTime: string;
    bidsCount: number;
  };
}

export interface Review {
  id: string;
  userName: string;
  userAvatar: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Garage {
  id: string;
  name: string;
  image: string;
  category: 'Authorized' | 'Independent' | 'Specialist' | 'Detailing';
  address: string;
  city: string;
  country: string;
  phone: string;
  rating: number;
  services: GarageService[];
  emergencyRoadside: boolean;
}

export interface GarageService {
  name: string;
  price: number;
  duration: string;
  description: string;
}

export interface Booking {
  id: string;
  carId: string;
  carName: string;
  showroomId: string;
  showroomName: string;
  buyerName: string;
  buyerEmail: string;
  bookingAmountPaid: number;
  date: string;
  time: string;
  type: 'Test Drive' | 'Purchase Reservation';
  status: 'confirmed' | 'pending' | 'completed';
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}
