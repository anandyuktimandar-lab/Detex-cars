import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;

// Initialize Gemini SDK with custom user agent and fallback check
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini SDK successfully initialized on server.");
  } catch (error) {
    console.error("Failed to initialize Gemini SDK:", error);
  }
} else {
  console.log("GEMINI_API_KEY not found in environment. Server will use highly intelligent rule-based fallbacks.");
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // 1. CHATBOT ENDPOINT
  app.post("/api/gemini/chat", async (req, res) => {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    if (ai) {
      try {
        // Construct standard prompt with context
        const sysInstruction = `You are "Detex AI", an elite, world-class automotive assistant, car analyst, future price forecaster, and AI concierge for Detex - a premium, high-tech, luxury global car ecosystem. 
You can answer questions regarding hypercars, luxury EVs, performance specifications, charging systems, international pricing, resale valuations, and direct physical showroom integrations.
Respond with stylish, human, scannable Markdown. Maintain a luxury, technical, and objective tone. Do not use generic hyperbole, but give insightful, precise data. Keep answers highly concise to fit in a premium slide-over side panel.`;

        // Format history for contents
        const formattedContents = [];
        if (history && Array.isArray(history)) {
          for (const msg of history) {
            formattedContents.push({
              role: msg.sender === 'user' ? 'user' : 'model',
              parts: [{ text: msg.text }]
            });
          }
        }
        formattedContents.push({
          role: 'user',
          parts: [{ text: message }]
        });

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: formattedContents,
          config: {
            systemInstruction: sysInstruction,
            temperature: 0.7,
          }
        });

        const reply = response.text || "I was unable to formulate a response at this time. How can I help you find your dream hypercar?";
        return res.json({ reply });
      } catch (err: any) {
        console.error("Gemini Chat API Error:", err);
        return res.json({ 
          reply: `*AI Offline Mode (API Key connection failed)*\n\nI can still address your search! Based on high-end automotive statistics, the vehicle you are asking about has remarkable acceleration, highly optimized power curves, and high demand in leading cities. How else can I assist?` 
        });
      }
    } else {
      // Heuristics fallback
      let reply = "";
      const lower = message.toLowerCase();
      if (lower.includes("price") || lower.includes("cost") || lower.includes("predict")) {
        reply = "⚡ **Detex Future Value Forecast:** Modern hypercars like the Revuelto and Taycon Turbo GT retain up to 84% value in year one under UAE and US climate settings. Within five years, luxury EVs experience steep depreciation profiles (falling to ~45%), whereas rare mechanical editions like the Bugatti Tourbillon or Porsche 911 GT3 RS display appreciation spikes of +15% to +25% due to limited allocations.";
      } else if (lower.includes("electric") || lower.includes("ev") || lower.includes("battery")) {
        reply = "🔋 **Battery & Electric Performance Profile:** Next-generation 800V silicon-carbide architectures support ultrafast replenishing. A Taycan Turbo GT or Tesla Model S Plaid can recover from 10% to 80% charge in 18 minutes. Resale metrics stay highly reliant on battery SOH (State of Health) diagnostics, which Detex automatically certifies via real-time telemetry scans.";
      } else if (lower.includes("showroom")) {
        reply = "🗺️ **Real-Time Integration:** Showrooms connect live using their proprietary dealership management APIs or direct manual updates in our Dealer Portal. The verified badges and pricing integrity are scanned daily by our background validation daemon to shield customers from phantom charges and fake prices.";
      } else {
        reply = "Welcome to Detex Auto! I can assist you with active car comparison data, real-time inventory at Aether Vegas or Tokyo Apex, resale forecasts, or setting up test ride booking requests.";
      }
      return res.json({ reply });
    }
  });

  // 2. FUTURE PRICE PREDICTION ENDPOINT
  app.post("/api/gemini/predict-price", async (req, res) => {
    const { modelName, brand, priceExShowroom, condition, mileage, year } = req.body;
    
    if (!priceExShowroom) {
      return res.status(400).json({ error: "Base ex-showroom price is required." });
    }

    const startPrice = parseFloat(priceExShowroom);
    const isCollectible = ['bugatti', 'ferrari', 'lamborghini', 'porsche'].some(b => brand?.toLowerCase().includes(b)) && !['taycan', 'cayenne'].some(m => modelName?.toLowerCase().includes(m));
    const isEv = ['tesla', 'taycan', 'ev', 'etron', 'electric'].some(term => modelName?.toLowerCase().includes(term) || brand?.toLowerCase().includes(term));

    if (ai) {
      try {
        const prompt = `Perform an elite luxury automotive analysis and generate a future price prediction over 5 years (Years: 1, 2, 3, 4, 5) for a ${year} ${brand} ${modelName} (Condition: ${condition}, Mileage: ${mileage}, Ex-Showroom local value: $${startPrice}).
Return your prediction response as a strict, valid JSON object following this exact schema structure:
{
  "projectedValues": [
    {"year": 1, "valueUsd": number, "percentage": number},
    {"year": 2, "valueUsd": number, "percentage": number},
    {"year": 3, "valueUsd": number, "percentage": number},
    {"year": 4, "valueUsd": number, "percentage": number},
    {"year": 5, "valueUsd": number, "percentage": number}
  ],
  "marketAnalysis": "A very professional 3-sentence summary of why this vehicle depreciates or appreciates, highlighting collectability, battery state, or ICE scarcity."
}
Only output the raw JSON, no Markdown code block wrap, no extra text formatting.`;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            temperature: 0.2,
          }
        });

        if (response.text) {
          const parsed = JSON.parse(response.text.trim());
          return res.json(parsed);
        }
      } catch (err) {
        console.error("Gemini Predict Price Error, defaulting to rule scheme:", err);
      }
    }

    // Heuristics prediction algorithm
    const trendList = [];
    let currentVal = startPrice;
    
    for (let i = 1; i <= 5; i++) {
      let depreciationFactor = 0;
      if (isCollectible) {
        // Limited editions retain or appreciate
        if (i === 1) depreciationFactor = -0.05; // 5% drop onroad registration
        else if (i === 2) depreciationFactor = 0.02; // stability
        else depreciationFactor = 0.05; // 5% annual gain
      } else if (isEv) {
        // steeper transition
        depreciationFactor = i === 1 ? 0.22 : 0.12;
      } else {
        // Standard high-performance
        depreciationFactor = i === 1 ? 0.15 : 0.09;
      }

      currentVal = currentVal * (1 - depreciationFactor);
      trendList.push({
        year: i,
        valueUsd: Math.round(currentVal),
        percentage: Math.round((currentVal / startPrice) * 100)
      });
    }

    const marketAnalysis = isCollectible 
      ? `As a rare mechanical limited release, the ${brand} ${modelName} benefits heavily from internal combustion engine (ICE) scarcity. Expect significant secondary collector premium curves to develop beyond Year 3.`
      : isEv 
      ? `Being an ultra-performance EV, the pace of battery energy density innovation will apply natural pressure onto current battery architectures, yielding a standard modern electronics depreciation curve. Keep battery state certified.`
      : `The ${brand} ${modelName} represents stable high-performance dynamics. It exhibits moderate styling updates every 4 years, keeping its residual values firmly in line with tier-1 German performance indices.`;

    return res.json({
      projectedValues: trendList,
      marketAnalysis
    });
  });

  // 3. AI PERSONALIZED CAR RECOMMENDATION
  app.post("/api/gemini/recommend", async (req, res) => {
    const { budgetUsd, preference, evPreference, region } = req.body;
    
    const budget = budgetUsd ? parseInt(budgetUsd) : 250000;

    if (ai) {
      try {
        const prompt = `As a high-tech car agent, recommend three high-end cars that would best suit a buyer in ${region || "globally"} with a budget of limit $${budget} USD, who prefers ${preference || "high performance"} and prefers EV level: ${evPreference || "open to both"}.
Return a strict valid JSON array containing exactly three items. The structure of each item must be:
{
  "brand": "string",
  "model": "string",
  "estimatedPriceUsd": number,
  "suitabilityScore": number (out of 100),
  "rationale": "one sentence explaining why"
}
Only output the raw JSON array.`;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            temperature: 0.4,
          }
        });

        if (response.text) {
          const parsed = JSON.parse(response.text.trim());
          return res.json(parsed);
        }
      } catch (err) {
        console.error("Gemini Recommendation Error, using rules fallback:", err);
      }
    }

    // Heuristics recommendation generator
    const fallbackRecs = [
      {
        brand: "Tesla",
        model: "Model S Plaid",
        estimatedPriceUsd: 89990,
        suitabilityScore: budget >= 90000 ? 98 : 85,
        rationale: "Unbelievable acceleration profiles and elite battery engineering standard for EV lovers."
      },
      {
        brand: "Porsche",
        model: "Taycan Turbo GT",
        estimatedPriceUsd: 230000,
        suitabilityScore: budget >= 230000 ? 95 : 60,
        rationale: "Pure mechanical racetrack precision combined with a blazing-fast 800V silicon-carbide system."
      },
      {
        brand: "BMW",
        model: "i7 M70 xDrive",
        estimatedPriceUsd: 168500,
        suitabilityScore: budget >= 168500 ? 92 : 70,
        rationale: "A moving digital cinema experience featuring unparalleled private cabin ride comfort."
      }
    ];

    return res.json(fallbackRecs);
  });

  // Vite Integration for Full-Stack Hot Module Replacement or Production Build
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite dev middleware mounted successfully in server.ts");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FULLSTACK SERVER] Running on host 0.0.0.0, port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error("Critical error starting Express backend:", error);
});
