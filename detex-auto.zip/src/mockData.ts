import { Car, Showroom, Garage, Booking, Lead } from './types';

export const CURRENCY_SYMBOLS = {
  USD: '$',
  EUR: '€',
  INR: '₹',
  AED: 'AED ',
  GBP: '£',
};

export const CURRENCY_CONVERSION = {
  USD: 1,
  EUR: 0.92,
  INR: 83,
  AED: 3.67,
  GBP: 0.79,
};

export const formatPrice = (amountUsd: number, currency: 'USD' | 'EUR' | 'INR' | 'AED' | 'GBP') => {
  const rate = CURRENCY_CONVERSION[currency];
  const symbol = CURRENCY_SYMBOLS[currency];
  const converted = Math.round(amountUsd * rate);
  
  if (currency === 'INR') {
    return `${symbol} ${converted.toLocaleString('en-IN')}`;
  }
  return `${symbol}${converted.toLocaleString()}`;
};

export const MOCK_SHOWROOMS: Showroom[] = [
  {
    id: 'sr-1',
    name: 'Aether Hypercars Vegas',
    logo: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=150&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=1200&q=80',
    verified: true,
    address: 'Strip Skyline Blvd, Las Vegas',
    city: 'Las Vegas',
    country: 'United States',
    phone: '+1 (702) 555-0199',
    whatsapp: '17025550199',
    email: 'vegas@aetherhypercars.com',
    socials: {
      instagram: '@aether_hypercars',
      twitter: '@aether_vegas',
    },
    rating: 4.9,
    reviewsCount: 142,
    reviews: [
      {
        id: 'rev-1',
        userName: 'Alexander Wright',
        userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
        rating: 5,
        comment: 'Outstanding support while purchasing our Revuelto. The physical showroom integration preview and transparent on-road taxes calculations were completely custom and pristine.',
        date: '2026-05-18',
      },
      {
        id: 'rev-2',
        userName: 'Hana Al-Maktoum',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80',
        rating: 5,
        comment: 'Incredibly smooth interaction. Best luxury experience ever.',
        date: '2026-04-22',
      }
    ],
    featuredModels: ['car-1', 'car-2'],
    analytics: {
      monthlyViews: 45200,
      leadsGenerated: 198,
      activeCars: 5,
      conversionRate: 4.2,
    }
  },
  {
    id: 'sr-2',
    name: 'Tokyo Apex Electric Hub',
    logo: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=150&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
    verified: true,
    address: 'Chiyoda Center Ward, Tokyo',
    city: 'Tokyo',
    country: 'Japan',
    phone: '+81 3-5555-0143',
    whatsapp: '81355550143',
    email: 'tokyo@apex-ev.jp',
    socials: {
      instagram: '@apex_tokyo',
      twitter: '@apex_ev',
    },
    rating: 4.8,
    reviewsCount: 89,
    reviews: [],
    featuredModels: ['car-3', 'car-4'],
    analytics: {
      monthlyViews: 32000,
      leadsGenerated: 145,
      activeCars: 4,
      conversionRate: 3.9,
    }
  },
  {
    id: 'sr-3',
    name: 'Prestige Munich Auto',
    logo: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=150&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1486496146582-9ffcd0b2b2b7?auto=format&fit=crop&w=1200&q=80',
    verified: true,
    address: 'Balanstrasse 88, Munich',
    city: 'Munich',
    country: 'Germany',
    phone: '+49 89 555-4321',
    whatsapp: '49895554321',
    email: 'munich@prestigeauto.de',
    socials: {
      instagram: '@prestige_munich',
      facebook: '@prestigegmbh',
    },
    rating: 4.7,
    reviewsCount: 76,
    reviews: [],
    featuredModels: ['car-5', 'car-6'],
    analytics: {
      monthlyViews: 28000,
      leadsGenerated: 112,
      activeCars: 6,
      conversionRate: 3.5,
    }
  },
  {
    id: 'sr-4',
    name: 'Gulf Luxury Motorsports',
    logo: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=150&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1200&q=80',
    verified: true,
    address: 'Sheik Zayed Spine, Dubai Marina',
    city: 'Dubai',
    country: 'United Arab Emirates',
    phone: '+971 4 555-0182',
    whatsapp: '97145550182',
    email: 'dubai@gulfmotorsports.ae',
    socials: {
      instagram: '@gulf_luxury_motors',
    },
    rating: 4.9,
    reviewsCount: 215,
    reviews: [],
    featuredModels: ['car-7'],
    analytics: {
      monthlyViews: 85000,
      leadsGenerated: 420,
      activeCars: 8,
      conversionRate: 5.1,
    }
  }
];

export const MOCK_CARS: Car[] = [
  {
    id: 'car-1',
    brand: 'Lamborghini',
    model: 'Revuelto',
    year: 2026,
    category: 'Luxury',
    condition: 'New',
    priceExShowroom: 608000,
    priceOnRoad: 642000,
    emiBase: 8900,
    whatsapp: '17025550199',
    insuranceEstimate: 12500,
    showroomId: 'sr-1',
    showroomName: 'Aether Hypercars Vegas',
    mileage: '6.2 km/l (V12 Plug-in Hybrid)',
    topSpeed: 350,
    horsepower: 1015,
    torque: 807,
    acceleration: '2.5s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1621135802920-133df287f89c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Arancio Apodis', hex: '#FF5722' },
      { name: 'Verde Turbine', hex: '#3E4E3E' },
      { name: 'Nero Pegaso', hex: '#111111' }
    ],
    availability: 'Pre-Order Only',
    city: 'Las Vegas',
    country: 'United States',
    pros: [
      'Incredible V12 hybrid mechanical power producing 1015 HP.',
      'Precision state-of-the-art torque vectoring and interactive steering.',
      'Astounding futuristic interior cockpit feeling like a stealth fighter jet.'
    ],
    cons: [
      'Extremely premium luxury pricing with prolonged delivery wait times.',
      'Extremely high fuel consumption under purely acoustic V12 mode.',
      'Very limited luggage headroom spaces ideal only for overnight baggage.'
    ]
  },
  {
    id: 'car-2',
    brand: 'Tesla',
    model: 'Model S Plaid',
    year: 2026,
    category: 'EV',
    condition: 'New',
    priceExShowroom: 89990,
    priceOnRoad: 96500,
    emiBase: 1320,
    whatsapp: '17025550199',
    insuranceEstimate: 2100,
    showroomId: 'sr-1',
    showroomName: 'Aether Hypercars Vegas',
    mileage: '637 km Range (Electric)',
    topSpeed: 322,
    horsepower: 1020,
    torque: 1420,
    acceleration: '1.99s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1619767886558-efdc259cde1a?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Solid Black', hex: '#0a0a0a' },
      { name: 'Ultra Red', hex: '#CC1F26' },
      { name: 'Pearl White Multi-Coat', hex: '#FAFAFA' }
    ],
    availability: 'In Stock',
    city: 'Las Vegas',
    country: 'United States',
    pros: [
      'World-record hypercar accelerating state of 0-100 km/h in 1.99 seconds.',
      'Exceptional thermal management, tri-motor vector control and 1020 HP.',
      'Unmatched battery charging intelligence and Supercharging ecosystem access.'
    ],
    cons: [
      'Yoke steering feels heavy during sharp low-speed residential rotations.',
      'Interior visual fit/finish falls behind similarly priced German brands.',
      'High insurance premiums due to insane acceleration indices.'
    ]
  },
  {
    id: 'car-3',
    brand: 'Porsche',
    model: 'taycan Turbo GT',
    year: 2026,
    category: 'EV',
    condition: 'New',
    priceExShowroom: 230000,
    priceOnRoad: 247000,
    emiBase: 3450,
    whatsapp: '81355550143',
    insuranceEstimate: 4800,
    showroomId: 'sr-2',
    showroomName: 'Tokyo Apex Electric Hub',
    mileage: '555 km Range (Electric)',
    topSpeed: 305,
    horsepower: 1033,
    torque: 1340,
    acceleration: '2.2s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611245041358-18e4ddf402c5?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Purple Metallic', hex: '#4B0082' },
      { name: 'Ice Grey Metallic', hex: '#D2D7DF' },
      { name: 'Nero Vulcano', hex: '#1C1C1C' }
    ],
    availability: 'Pre-Order Only',
    city: 'Tokyo',
    country: 'Japan',
    pros: [
      'Record-breaking performance around Nürburgring circuit.',
      'Unsurpassed electronic feedback mechanics custom to Porsche racing.',
      '800V fast-charge structure supporting 10% to 80% charging in 18 minutes.'
    ],
    cons: [
      'Rear occupancy is extremely cramped with low-slung performance ceiling.',
      'Highly expensive initial price options with no adaptive autonomy standard.'
    ]
  },
  {
    id: 'car-4',
    brand: 'Nissan',
    model: 'GT-R Nismo',
    year: 2025,
    category: 'Luxury',
    condition: 'Certified',
    priceExShowroom: 220000,
    priceOnRoad: 236000,
    emiBase: 3200,
    whatsapp: '81355550143',
    insuranceEstimate: 4200,
    showroomId: 'sr-2',
    showroomName: 'Tokyo Apex Electric Hub',
    mileage: '7.8 km/l (Twin-Turbo V6)',
    topSpeed: 315,
    horsepower: 600,
    torque: 652,
    acceleration: '2.8s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Solid Matte Gray', hex: '#707070' },
      { name: 'Ultimate Red', hex: '#B22222' }
    ],
    availability: 'In Stock',
    city: 'Tokyo',
    country: 'Japan',
    pros: [
      'Incredible mechanical traction mechanics and all-wheel-drive system.',
      'Outstanding track styling signature, exclusive carbon fiber bodywork.',
      'High future resale value as the final internal combustion GT-R iteration.'
    ],
    cons: [
      'Rough transmission shifting inside everyday bumper-to-bumper city roads.',
      'Outdated infotainment styling and heavy analog dial gauges.'
    ]
  },
  {
    id: 'car-5',
    brand: 'BMW',
    model: 'i7 M70 xDrive',
    year: 2026,
    category: 'Luxury',
    condition: 'New',
    priceExShowroom: 168500,
    priceOnRoad: 181000,
    emiBase: 2450,
    whatsapp: '49895554321',
    insuranceEstimate: 3600,
    showroomId: 'sr-3',
    showroomName: 'Prestige Munich Auto',
    mileage: '560 km Range (Electric)',
    topSpeed: 250,
    horsepower: 650,
    torque: 1100,
    acceleration: '3.7s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1607853202273-797f1c22a38e?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Two-Tone Oxide Grey / Sapphire Blue', hex: '#5F6F7F' },
      { name: 'Black Sapphire Metallic', hex: '#0B0B0C' }
    ],
    availability: 'In Stock',
    city: 'Munich',
    country: 'Germany',
    pros: [
      'The ultimate luxury cinema experience with a 31.3-inch 8K theater screen.',
      'Stunning sound engineering with premium Bowers & Wilkins surround systems.',
      'Super-comfortable active roll stabilization feels like cruising on tracks.'
    ],
    cons: [
      'Highly futuristic split twin-headlight grille design is polarizing.',
      'The dynamic heavy frame (exceeds 2.7 tons) impacts sports steering agility.'
    ]
  },
  {
    id: 'car-6',
    brand: 'Mercedes-Benz',
    model: 'AMG GT 63 S E Performance',
    year: 2026,
    category: 'Luxury',
    condition: 'New',
    priceExShowroom: 195000,
    priceOnRoad: 211000,
    emiBase: 2900,
    whatsapp: '49895554321',
    insuranceEstimate: 3900,
    showroomId: 'sr-3',
    showroomName: 'Prestige Munich Auto',
    mileage: '12.4 km/l (V8 Hybrid)',
    topSpeed: 316,
    horsepower: 843,
    torque: 1470,
    acceleration: '2.9s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1617531653332-bd46c24f2068?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Designo Selenite Grey', hex: '#63656A' },
      { name: 'Manufactur Green Hell Magno', hex: '#2E8B57' }
    ],
    availability: 'In Stock',
    city: 'Munich',
    country: 'Germany',
    pros: [
      'A true mechanical V8 beast supplemented by dual electric formula tech.',
      'Amazing high-performance sport cabin with premium carbon trim.'
    ],
    cons: [
      'Extremely complex hybrid system that requires high cost of maintenance.',
      'Complex steering wheel dial selections may confuse daily commuters.'
    ]
  },
  {
    id: 'car-7',
    brand: 'Bugatti',
    model: 'Tourbillon',
    year: 2027,
    category: 'Luxury',
    condition: 'New',
    priceExShowroom: 4100000,
    priceOnRoad: 435000, // Normalized for on-road calculations or exact index
    emiBase: 58000,
    whatsapp: '97145550182',
    insuranceEstimate: 95000,
    showroomId: 'sr-4',
    showroomName: 'Gulf Luxury Motorsports',
    mileage: '4.5 km/l (V16 Naturally Aspirated)',
    topSpeed: 445,
    horsepower: 1800,
    torque: 2000,
    acceleration: '2.0s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1600706432502-75e0eec49e9e?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Bleu de France', hex: '#0055A5' },
      { name: 'Carbon Black Edition', hex: '#080808' }
    ],
    availability: 'Pre-Order Only',
    city: 'Dubai',
    country: 'United Arab Emirates',
    pros: [
      'Engineering masterpiece utilizing an 8.35L V16 with analog watch design counters.',
      'True legendary hypercar collectability status limited to 250 units worldwide.'
    ],
    cons: [
      'Intense, astronomical purchase barrier, service costs, and taxes.',
      'Minimum wait periods extending out through 2028 depending on client level.'
    ]
  },
  {
    id: 'car-8',
    brand: 'Porsche',
    model: '911 GT3 RS',
    year: 2025,
    category: 'Luxury',
    condition: 'Certified',
    priceExShowroom: 223800,
    priceOnRoad: 242000,
    emiBase: 3100,
    whatsapp: '97145550182',
    insuranceEstimate: 4500,
    showroomId: 'sr-4',
    showroomName: 'Gulf Luxury Motorsports',
    mileage: '7.2 km/l (Flat-6 Engine)',
    topSpeed: 296,
    horsepower: 518,
    torque: 465,
    acceleration: '3.2s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611245041358-18e4ddf402c5?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Guards Red / Schwarz Combo', hex: '#D21F3C' },
      { name: 'Signal Green', hex: '#228B22' }
    ],
    availability: 'In Stock',
    city: 'Dubai',
    country: 'United Arab Emirates',
    pros: [
      'Unrivaled active-aerodynamics package with DRS (Drag Reduction System).',
      'The world\'s most vocal high-revving naturally aspirated 9,000 RPM peak.'
    ],
    cons: [
      'Extremely noise-filled high-frequency cabin with zero comfort options.',
      'No rear trunk space because of massive engine-associated active cooling ducting.'
    ]
  },
  {
    id: 'car-9',
    brand: 'Ferrari',
    model: 'SF90 Stradale',
    year: 2025,
    category: 'Luxury',
    condition: 'Used',
    priceExShowroom: 524000,
    priceOnRoad: 549000,
    emiBase: 7600,
    whatsapp: '97145550182',
    insuranceEstimate: 11000,
    showroomId: 'sr-4',
    showroomName: 'Gulf Luxury Motorsports',
    mileage: '11.1 km/l (Hybrid V8)',
    topSpeed: 340,
    horsepower: 986,
    torque: 800,
    acceleration: '2.5s',
    safetyRating: 5,
    gallery: [
      'https://images.unsplash.com/photo-1592853625597-7d17be820d0c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Rosso Corsa', hex: '#E00B0B' },
      { name: 'Giallo Modena', hex: '#FAD105' }
    ],
    availability: 'In Stock',
    city: 'Dubai',
    country: 'United Arab Emirates',
    pros: [
      'Exceptional plug-in hyper-dynamics, delivering insane levels of torque output.',
      'Extreme cornering threshold equipped with premium electronic drift assists.'
    ],
    cons: [
      'The pure electric range is restricted to a maximum 25 kilometers.',
      'Touchpad interface buttons on steering wheel are prone to accidental triggering.'
    ]
  }
];

export const MOCK_GARAGES: Garage[] = [
  {
    id: 'g-1',
    name: 'Bavarian Precision Tuning Corp.',
    image: 'https://images.unsplash.com/photo-1486496146582-9ffcd0b2b2b7?auto=format&fit=crop&w=400&q=80',
    category: 'Authorized',
    address: 'Einstein Ring 808, Ottobrunn',
    city: 'Munich',
    country: 'Germany',
    phone: '+49 89 555-8889',
    rating: 4.9,
    emergencyRoadside: true,
    services: [
      { name: 'Carbon Ceramic Brake Refitting', price: 3400, duration: '1 Day', description: 'Complete installation of premium composite friction discs and specialized high-performance pads.' },
      { name: 'ECU Mapping & Dynamic Dyno Run', price: 1200, duration: '4 Hours', description: 'Advanced engine controller telemetry optimization tuned specifically under load settings.' },
      { name: 'Scheduled Hypercar Diagnostic Service', price: 650, duration: '2 Hours', description: 'High-frequency vehicle scan looking over mechanical systems and batteries.' }
    ]
  },
  {
    id: 'g-2',
    name: 'Neo-Tokyo Custom Engineering',
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=400&q=80',
    category: 'Specialist',
    address: 'Shibuya Crossing Underpass No. 4',
    city: 'Tokyo',
    country: 'Japan',
    phone: '+81 3-5555-9000',
    rating: 4.8,
    emergencyRoadside: true,
    services: [
      { name: 'Ultra-Performance EV Suspension Setup', price: 1950, duration: '6 Hours', description: 'Upgrade to active adaptive suspension arrays with custom damper responses.' },
      { name: 'Ceramic Glass Coated Detailing Paint Prep', price: 900, duration: '2 Days', description: 'Triple layering of elite synthetic liquid silica to repel weather and road micro-impacts.' }
    ]
  },
  {
    id: 'g-3',
    name: 'Vegas Apex Overhaul & Roadside Support',
    image: 'https://images.unsplash.com/photo-1619767886558-efdc259cde1a?auto=format&fit=crop&w=400&q=80',
    category: 'Specialist',
    address: 'Highway Circle Road, Las Vegas Strip',
    city: 'Las Vegas',
    country: 'United States',
    phone: '+1 (702) 555-9876',
    rating: 4.7,
    emergencyRoadside: true,
    services: [
      { name: '24/7 Desert Highway Emergency Tow & Repair', price: 250, duration: 'Immediate', description: 'Heavy towing, vehicle recovery, tire updates, and on-spot charging.' },
      { name: 'Trackday Dynamic Inspection Checklist', price: 350, duration: '1.5 Hours', description: 'Full track safety analysis across fluids, heat tolerances, and telemetry logs.' }
    ]
  }
];

export const INITIAL_LEADS: Lead[] = [
  {
    id: 'lead-1',
    carId: 'car-1',
    carName: 'Lamborghini Revuelto',
    buyerName: 'Vikram Singh',
    buyerEmail: 'vikram.singh@mumbai.in',
    buyerPhone: '+91 98765 43210',
    message: 'I am highly interested in securing an immediate allocation for the Revuelto. Please share custom delivery timelines to Dubai. I have funds ready to initiate reservation today.',
    status: 'pending',
    date: '2026-05-20T14:32:00Z'
  },
  {
    id: 'lead-2',
    carId: 'car-2',
    carName: 'Tesla Model S Plaid',
    buyerName: 'Sarah Connor',
    buyerEmail: 'sarah.c@techcorp.io',
    buyerPhone: '+1 (512) 555-0100',
    message: 'Can the Plaid model do immediate deliveries? I would like to book a private VIP test ride on Saturday at the Las Vegas center.',
    status: 'contacted',
    date: '2026-05-19T09:15:00Z'
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'book-1',
    carId: 'car-2',
    carName: 'Tesla Model S Plaid',
    showroomId: 'sr-1',
    showroomName: 'Aether Hypercars Vegas',
    buyerName: 'Anand Kumar',
    buyerEmail: 'anand.yukti.mandar@gmail.com',
    bookingAmountPaid: 5000,
    date: '2026-05-24',
    time: '14:00',
    type: 'Test Drive',
    status: 'confirmed'
  }
];
